#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Shutdown Scheduler - password-protected PC shutdown timer for Windows.

Features
--------
* Tkinter GUI, standard library only (compiles to one .exe with PyInstaller).
* Password-protected dashboard (PBKDF2 hash, lock-out after wrong attempts,
  auto-lock after inactivity, password can be changed).
* At the scheduled time the program checks whether the PC is in use (keyboard /
  mouse activity).  If it is, a large full-screen warning stays up (30 s by
  default) with buttons / a text box to postpone the shutdown.
* EVERY limit is editable inside the program (Limits + Security tabs): warning
  length, postpone buttons, longest / maximum number / maximum total postpone,
  idle time, missed-schedule grace, auto-lock, password attempts, lock-out time,
  minimum password length.
* Closing the window only hides it - the scheduler keeps running.  Starting the
  program a second time re-opens the (locked) dashboard of the running copy.
* Optional "Start with Windows" and "Restart as administrator" support.
* All work happens on the Tk main loop (timers) or in small helper threads, so
  the GUI never freezes.

Command line (all optional)
---------------------------
  --background   start hidden (used by the auto-start entry)
  --dry-run      never really shut down; only show what would happen (testing)
"""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import hmac
import json
import logging
import logging.handlers
import math
import os
import queue
import secrets
import socket
import subprocess
import sys
import tempfile
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
import zlib
from datetime import datetime, timedelta
from tkinter import messagebox, ttk

IS_WINDOWS = sys.platform.startswith("win")
if IS_WINDOWS:
    import winreg
    import winsound

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #
APP_NAME = "ShutdownScheduler"
APP_TITLE = "Shutdown Scheduler"
PBKDF2_ITERATIONS = 200_000
SHUTDOWN_BUSY_SECONDS = 90           # ignore new triggers while a shutdown is in progress
IPC_HOST = "127.0.0.1"
def _ipc_port() -> int:
    """Per-user local port, so two Windows users on one PC never block each other."""
    user = (os.environ.get("USERNAME") or os.environ.get("USER") or "user").lower()
    return 49152 + zlib.crc32(user.encode("utf-8")) % 12000


IPC_PORT = _ipc_port()               # used only to detect / contact the running copy
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"

log = logging.getLogger(APP_NAME)
log.addHandler(logging.NullHandler())


# --------------------------------------------------------------------------- #
# Paths, logging, global error handling
# --------------------------------------------------------------------------- #
def data_dir() -> str:
    """Folder for config + log (%APPDATA%\\ShutdownScheduler on Windows)."""
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    path = os.path.join(base, APP_NAME)
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        path = os.path.join(tempfile.gettempdir(), APP_NAME)
        os.makedirs(path, exist_ok=True)
    return path


def setup_logging() -> None:
    """Log to a small rotating file (a --noconsole exe has no stdout/stderr)."""
    try:
        handler = logging.handlers.RotatingFileHandler(
            os.path.join(data_dir(), "scheduler.log"),
            maxBytes=200_000, backupCount=1, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(handler)
        log.setLevel(logging.INFO)
    except OSError:
        pass

    def _hook(exc_type, exc, tb):
        log.critical("Uncaught exception", exc_info=(exc_type, exc, tb))

    sys.excepthook = _hook
    if hasattr(threading, "excepthook"):
        threading.excepthook = lambda a: log.critical(
            "Uncaught thread exception", exc_info=(a.exc_type, a.exc_value, a.exc_traceback))


def enable_dpi_awareness() -> None:
    """Avoid blurry text on high-DPI Windows screens."""
    if not IS_WINDOWS:
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Configuration (JSON file, atomic writes)
# --------------------------------------------------------------------------- #
DEFAULTS = {
    "pw_salt": "", "pw_hash": "", "pw_iter": PBKDF2_ITERATIONS,
    "enabled": False,        # is a shutdown currently scheduled?
    "target_ts": 0.0,        # epoch seconds of the next shutdown
    "mode": "at",            # "at" = clock time, "after" = N minutes from now
    "repeat_daily": False,   # only used with mode "at"
    "hour": 22, "minute": 0, "after_minutes": 60,
    "always_warn": False,    # show the warning even if the PC looks idle
    "force_close": True,     # shutdown /f : close apps that block the shutdown
    "autostart": False,
    # ---- limits (all editable in the dashboard) ----
    "warning_seconds": 30,   # length of the on-screen warning
    "preset1": 10, "preset2": 30, "preset3": 60,   # postpone buttons (minutes)
    "max_single": 1440,      # longest single postpone (minutes)
    "max_postpones": 0,      # max number of postpones per shutdown, 0 = unlimited
    "max_total": 0,          # max total postponed minutes per shutdown, 0 = unlimited
    "idle_minutes": 2,       # no input for this long => PC counts as idle
    "grace_minutes": 15,     # a schedule overdue by more than this is "missed"
    "autolock_seconds": 120, # dashboard locks itself after this much inactivity
    "max_attempts": 3,       # wrong passwords allowed before a lock-out starts
    "lockout_seconds": 30,   # first lock-out length (doubles with every further failure)
    "min_password": 4,       # minimum length of a NEW password
    # ---- postpone usage of the current shutdown (internal) ----
    "pp_count": 0, "pp_total": 0, "pp_started_ts": 0.0,
}

# Allowed (min, max) for every numeric setting; used for validation and when loading.
RANGES = {
    "hour": (0, 23), "minute": (0, 59), "after_minutes": (1, 7 * 24 * 60),
    "warning_seconds": (10, 600),
    "preset1": (1, 1440), "preset2": (1, 1440), "preset3": (1, 1440),
    "max_single": (1, 7 * 24 * 60),
    "max_postpones": (0, 100), "max_total": (0, 7 * 24 * 60),
    "idle_minutes": (1, 120), "grace_minutes": (1, 240),
    "autolock_seconds": (10, 3600), "max_attempts": (1, 10),
    "lockout_seconds": (5, 600), "min_password": (1, 32),
    "pp_count": (0, 10_000), "pp_total": (0, 10_000_000),
}

# Fields shown in the dashboard: (config key, label, hint)
LIMIT_FIELDS = {
    "limits": [
        ("warning_seconds", "Warning countdown", "seconds"),
        ("preset1", "Postpone button 1", "minutes"),
        ("preset2", "Postpone button 2", "minutes"),
        ("preset3", "Postpone button 3", "minutes"),
        ("max_single", "Longest single postpone", "minutes (also limits the typed value)"),
        ("max_postpones", "Max postpones per shutdown", "0 = unlimited"),
        ("max_total", "Max total postponed time", "minutes per shutdown, 0 = unlimited"),
        ("idle_minutes", "PC counts as idle after", "minutes without keyboard/mouse"),
        ("grace_minutes", "Skip a shutdown missed by", "more than N minutes (PC was off/asleep)"),
    ],
    "security": [
        ("autolock_seconds", "Auto-lock dashboard after", "seconds of inactivity"),
        ("max_attempts", "Wrong passwords before lock-out", "attempts"),
        ("lockout_seconds", "First lock-out lasts", "seconds (doubles each further failure)"),
        ("min_password", "Minimum password length", "characters (for new passwords)"),
    ],
}
FIELD_LABELS = {key: label for group in LIMIT_FIELDS.values() for key, label, _hint in group}


def _coerce(value, default):
    """Return value if it has the same type as default, else default."""
    if isinstance(default, bool):
        return value if isinstance(value, bool) else default
    if isinstance(value, bool):
        return default
    if isinstance(default, int):
        return int(value) if isinstance(value, (int, float)) else default
    if isinstance(default, float):
        return float(value) if isinstance(value, (int, float)) else default
    if isinstance(default, str):
        return value if isinstance(value, str) else default
    return default


def _clamp(value: int, low: int, high: int) -> int:
    return max(low, min(high, value))


class Config:
    def __init__(self) -> None:
        self.path = os.path.join(data_dir(), "config.json")
        self.data = dict(DEFAULTS)
        self.load()

    def __getitem__(self, key):
        return self.data[key]

    def __setitem__(self, key, value) -> None:
        self.data[key] = value

    def load(self) -> None:
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
            if not isinstance(raw, dict):
                raise ValueError("config root is not an object")
        except (OSError, ValueError) as exc:
            log.error("Config unreadable (%s); moving it aside", exc)
            try:
                os.replace(self.path, self.path + ".corrupt")
            except OSError:
                pass
            return
        for key, default in DEFAULTS.items():
            self.data[key] = _coerce(raw.get(key, default), default)
        d = self.data
        for key, (low, high) in RANGES.items():
            d[key] = _clamp(d[key], low, high)
        if d["mode"] not in ("at", "after"):
            d["mode"] = "at"

    def save(self) -> bool:
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(self.data, fh, indent=2)
            os.replace(tmp, self.path)
            return True
        except OSError:
            log.exception("Could not save config")
            return False


# --------------------------------------------------------------------------- #
# Password helpers
# --------------------------------------------------------------------------- #
def hash_password(password: str, salt: bytes | None = None,
                  iterations: int = PBKDF2_ITERATIONS) -> tuple[str, str]:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return salt.hex(), digest.hex()


def verify_password(password: str, salt_hex: str, hash_hex: str, iterations: int) -> bool:
    try:
        salt = bytes.fromhex(salt_hex)
        expected = bytes.fromhex(hash_hex)
    except ValueError:
        return False
    if not salt or not expected:
        return False
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, max(1, iterations))
    return hmac.compare_digest(digest, expected)


# --------------------------------------------------------------------------- #
# Time helpers
# --------------------------------------------------------------------------- #
def next_occurrence(hour: int, minute: int, after: datetime | None = None) -> datetime:
    """Next wall-clock time HH:MM strictly after `after` (default: now)."""
    after = after or datetime.now()
    candidate = after.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if candidate <= after:
        candidate += timedelta(days=1)
    return candidate


def fmt_postpone(minutes: int) -> str:
    """Label for a postpone button: '+10 minutes', '+1 hour', '+1 h 30 min'."""
    if minutes < 60:
        return f"+{minutes} minute" + ("" if minutes == 1 else "s")
    hours, rest = divmod(minutes, 60)
    if rest == 0:
        return f"+{hours} hour" + ("" if hours == 1 else "s")
    return f"+{hours} h {rest} min"


def fmt_hms(seconds: float) -> str:
    seconds = max(0, int(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


# --------------------------------------------------------------------------- #
# Windows helpers: idle time, admin rights, auto-start, shutdown
# --------------------------------------------------------------------------- #
class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]


def get_idle_seconds() -> float:
    """Seconds since the last keyboard/mouse input. 0.0 (= active) if unknown."""
    if not IS_WINDOWS:
        return 0.0
    try:
        info = LASTINPUTINFO()
        info.cbSize = ctypes.sizeof(LASTINPUTINFO)
        if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):
            return 0.0
        now_ticks = ctypes.windll.kernel32.GetTickCount() & 0xFFFFFFFF
        return ((now_ticks - info.dwTime) & 0xFFFFFFFF) / 1000.0   # handles tick wrap-around
    except Exception:
        log.exception("Idle detection failed")
        return 0.0


def is_admin() -> bool:
    try:
        if IS_WINDOWS:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False


def launch_command() -> tuple[str, list[str]]:
    """(executable, args) that start this program again - exe or script."""
    if getattr(sys, "frozen", False):
        return sys.executable, []
    exe = sys.executable
    pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")   # no console window
    if IS_WINDOWS and os.path.exists(pyw):
        exe = pyw
    return exe, [os.path.abspath(sys.argv[0])]


def relaunch_as_admin(extra_args: list[str]) -> bool:
    """Ask Windows (UAC) to start a new elevated copy. True if it was launched."""
    if not IS_WINDOWS:
        return False
    exe, base_args = launch_command()
    params = subprocess.list2cmdline(base_args + extra_args)
    if getattr(sys, "frozen", False):
        # PyInstaller >= 6.9: make the new copy unpack itself instead of reusing our temp dir.
        os.environ["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    try:
        result = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, None, 1)
        return int(result) > 32            # <= 32 means error / UAC prompt declined
    except Exception:
        log.exception("Elevation failed")
        return False


def autostart_command() -> str:
    exe, args = launch_command()
    return subprocess.list2cmdline([exe] + args + ["--background"])


def set_autostart(enabled: bool) -> tuple[bool, str]:
    """Add/remove the per-user Run entry (no admin rights needed)."""
    if not IS_WINDOWS:
        return False, "Auto-start is only available on Windows."
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
            if enabled:
                winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, autostart_command())
            else:
                try:
                    winreg.DeleteValue(key, APP_NAME)
                except FileNotFoundError:
                    pass
        return True, ""
    except OSError as exc:
        return False, str(exc)


def run_shutdown(force: bool, dry_run: bool) -> tuple[bool, str]:
    """Run `shutdown /s /t 0`. Returns (success, message). Never raises."""
    if dry_run:
        return True, "Dry run: the shutdown command was NOT executed."
    if not IS_WINDOWS:
        return False, "Shutting down is only supported on Windows."
    exe = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "shutdown.exe")
    if not os.path.exists(exe):
        exe = "shutdown"
    cmd = [exe, "/s", "/t", "0"] + (["/f"] if force else [])
    try:
        # stdin=DEVNULL is required in --noconsole builds (otherwise WinError 6).
        result = subprocess.run(
            cmd, stdin=subprocess.DEVNULL, capture_output=True, text=True, errors="replace",
            timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
    except (OSError, subprocess.SubprocessError) as exc:
        return False, f"Could not run shutdown.exe: {exc}"
    code = result.returncode
    detail = " ".join((result.stderr or result.stdout or "").split())
    if code == 0:
        return True, "Shutdown command accepted by Windows."
    if code in (1115, 1190):                      # already scheduled / in progress
        return True, "A shutdown is already in progress."
    if code == 5:
        return False, ("Windows refused the shutdown request (access denied).\n\n"
                       "Open the dashboard and click 'Restart as administrator', then try again.")
    return False, f"shutdown.exe failed (exit code {code}): {detail or 'no details'}"


# --------------------------------------------------------------------------- #
# Single instance + "show dashboard" requests over a local socket
# --------------------------------------------------------------------------- #
class SingleInstance:
    """Holds a localhost port so only one copy runs; later copies ask it to show."""

    def __init__(self) -> None:
        self.sock: socket.socket | None = None
        self.events: queue.Queue = queue.Queue()
        self._stop = threading.Event()

    def _try_bind(self) -> bool:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            if IS_WINDOWS:
                if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):    # nobody else may share the port
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            else:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((IPC_HOST, IPC_PORT))
            sock.listen(5)
        except OSError:
            sock.close()
            return False
        self.sock = sock
        return True

    def acquire(self, retry_seconds: float = 0.0) -> bool:
        deadline = time.monotonic() + retry_seconds
        while True:
            if self._try_bind():
                threading.Thread(target=self._serve, args=(self.sock,),
                                 name="ipc", daemon=True).start()
                return True
            if time.monotonic() >= deadline:
                return False
            time.sleep(0.5)

    def _serve(self, sock: socket.socket) -> None:
        while not self._stop.is_set():
            try:
                conn, _addr = sock.accept()
            except OSError:
                break                              # socket closed
            with conn:
                try:
                    conn.settimeout(2.0)
                    if conn.recv(32).strip() == b"SHOW":
                        self.events.put("show")
                        conn.sendall(b"OK\n")
                        # Wait until the client hangs up first, so the lingering TIME_WAIT
                        # state lands on the client's port and not on ours (which would
                        # block a quick restart of the program).
                        conn.recv(1)
                except OSError:
                    pass

    def close(self) -> None:
        self._stop.set()
        if self.sock is not None:
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None


def ask_running_instance_to_show(timeout: float = 3.0) -> bool:
    """True if an existing Shutdown Scheduler answered our request."""
    try:
        with socket.create_connection((IPC_HOST, IPC_PORT), timeout=timeout) as conn:
            conn.sendall(b"SHOW\n")
            conn.settimeout(timeout)
            return conn.recv(16).strip() == b"OK"
    except OSError:
        return False


# --------------------------------------------------------------------------- #
# Look and feel: deep navy and black
# --------------------------------------------------------------------------- #
C_BLACK = "#04070d"
C_BG = "#0a1224"
C_CARD = "#0f1b33"
C_FIELD = "#08101f"
C_RAISED = "#16294a"
C_HOVER = "#1f3b6e"
C_BORDER = "#22406f"
C_ACCENT = "#3b82f6"
C_ACCENT_HI = "#5b9bff"
C_CYAN = "#38bdf8"
C_TEXT = "#e8eef8"
C_MUTED = "#8fa3c4"
C_OK = "#34d399"
C_BAD = "#f87171"
C_WARN = "#fbbf24"
C_DANGER = "#9f1f2a"
C_DANGER_HI = "#d12f3c"

FONTS = {"ui": "Segoe UI", "display": "Segoe UI"}


def init_fonts(root) -> None:
    """Pick the nicest installed fonts (Windows 10/11 ship Bahnschrift and Segoe UI)."""
    try:
        have = {name.lower() for name in tkfont.families(root)}
    except tk.TclError:
        have = set()

    def pick(candidates):
        for name in candidates:
            if name.lower() in have:
                return name
        return candidates[-1]

    FONTS["ui"] = pick(["Segoe UI", "Helvetica", "DejaVu Sans", "Arial"])
    FONTS["display"] = pick(["Bahnschrift SemiBold", "Bahnschrift", "Segoe UI Semibold",
                             "Segoe UI", "Helvetica", "DejaVu Sans", "Arial"])


def lerp_color(c1: str, c2: str, t: float) -> str:
    """Blend two #rrggbb colours (t = 0 gives c1, t = 1 gives c2)."""
    t = max(0.0, min(1.0, t))
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def ring_color(fraction: float) -> str:
    """Countdown ring colour: cyan while there is time, amber, then red."""
    if fraction > 0.5:
        return lerp_color("#fbbf24", C_CYAN, (fraction - 0.5) / 0.5)
    return lerp_color("#ef4444", "#fbbf24", fraction / 0.5)


def apply_theme(root) -> None:
    """Dark navy ttk theme (based on 'clam', the only theme that can be fully recoloured)."""
    ui, disp = FONTS["ui"], FONTS["display"]
    style = ttk.Style(root)
    style.theme_use("clam")
    root.configure(bg=C_BG)
    style.configure(".", background=C_CARD, foreground=C_TEXT, fieldbackground=C_FIELD,
                    bordercolor=C_BORDER, lightcolor=C_BORDER, darkcolor=C_BORDER,
                    troughcolor=C_FIELD, focuscolor=C_CARD, selectbackground=C_ACCENT,
                    selectforeground="#ffffff", insertcolor=C_TEXT, font=(ui, 10))
    style.configure("TFrame", background=C_CARD)
    style.configure("Bg.TFrame", background=C_BG)
    style.configure("Header.TFrame", background=C_BLACK)
    style.configure("TLabel", background=C_CARD, foreground=C_TEXT)
    style.configure("Bg.TLabel", background=C_BG)
    style.configure("Muted.TLabel", foreground=C_MUTED)
    style.configure("Title.TLabel", font=(disp, 17, "bold"))
    style.configure("Big.TLabel", font=(disp, 30, "bold"), foreground=C_CYAN)
    style.configure("Header.TLabel", background=C_BLACK)
    style.configure("HeaderTitle.TLabel", background=C_BLACK, font=(disp, 17, "bold"))
    style.configure("HeaderSub.TLabel", background=C_BLACK, foreground=C_MUTED, font=(ui, 9))

    style.configure("TButton", background=C_RAISED, foreground=C_TEXT, bordercolor=C_BORDER,
                    focusthickness=0, focuscolor=C_RAISED, padding=(14, 7), relief="flat")
    style.map("TButton", background=[("disabled", C_FIELD), ("pressed", C_ACCENT), ("active", C_HOVER)],
              foreground=[("disabled", C_MUTED)], bordercolor=[("active", C_ACCENT)])
    for name, base, hi in (("Accent", C_ACCENT, C_ACCENT_HI), ("Danger", C_DANGER, C_DANGER_HI)):
        style.configure(f"{name}.TButton", background=base, foreground="#ffffff", bordercolor=base)
        style.map(f"{name}.TButton", background=[("pressed", hi), ("active", hi)],
                  bordercolor=[("active", hi)])

    for name in ("TEntry", "TSpinbox"):
        style.configure(name, fieldbackground=C_FIELD, foreground=C_TEXT, insertcolor=C_TEXT,
                        bordercolor=C_BORDER, lightcolor=C_BORDER, darkcolor=C_BORDER,
                        padding=4, arrowcolor=C_MUTED, background=C_RAISED)
        style.map(name, bordercolor=[("focus", C_ACCENT)], lightcolor=[("focus", C_ACCENT)],
                  darkcolor=[("focus", C_ACCENT)], arrowcolor=[("active", C_TEXT)],
                  background=[("active", C_HOVER)])
    for name in ("TCheckbutton", "TRadiobutton"):
        style.configure(name, background=C_CARD, foreground=C_TEXT, indicatorbackground=C_FIELD,
                        indicatorforeground="#ffffff", upperbordercolor=C_BORDER,
                        lowerbordercolor=C_BORDER)
        style.map(name, background=[("active", C_CARD)],
                  indicatorbackground=[("selected", C_ACCENT), ("pressed", C_HOVER)],
                  foreground=[("disabled", C_MUTED)])

    style.configure("TNotebook", background=C_BG, borderwidth=0, tabmargins=(0, 0, 0, 0))
    style.configure("TNotebook.Tab", background="#0b1630", foreground=C_MUTED,
                    padding=(22, 9), borderwidth=0, font=(ui, 10))
    style.map("TNotebook.Tab", background=[("selected", C_CARD), ("active", "#12234a")],
              foreground=[("selected", C_TEXT), ("active", C_TEXT)])
    style.configure("TLabelframe", background=C_CARD, bordercolor=C_BORDER,
                    lightcolor=C_BORDER, darkcolor=C_BORDER)
    style.configure("TLabelframe.Label", background=C_CARD, foreground=C_CYAN, font=(ui, 10, "bold"))


def init_images(root) -> dict:
    """The program icon (embedded at the end of this file) as Tk images."""
    images = {}
    for key, data in (("icon", ICON_128_B64), ("logo", ICON_64_B64)):
        try:
            images[key] = tk.PhotoImage(master=root, data=data)
        except (tk.TclError, NameError):
            log.exception("Could not load the %s image", key)
    return images


def monitor_under_pointer():
    """(x, y, width, height) of the monitor the mouse is on (Windows); None if unknown."""
    if not IS_WINDOWS:
        return None
    try:
        from ctypes import wintypes

        class MONITORINFO(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                        ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]

        user32 = ctypes.windll.user32
        point = wintypes.POINT()
        if not user32.GetCursorPos(ctypes.byref(point)):
            return None
        user32.MonitorFromPoint.argtypes = [wintypes.POINT, wintypes.DWORD]
        user32.MonitorFromPoint.restype = ctypes.c_void_p
        user32.GetMonitorInfoW.argtypes = [ctypes.c_void_p, ctypes.POINTER(MONITORINFO)]
        monitor = user32.MonitorFromPoint(point, 2)          # MONITOR_DEFAULTTONEAREST
        info = MONITORINFO()
        info.cbSize = ctypes.sizeof(MONITORINFO)
        if not monitor or not user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
            return None
        r = info.rcMonitor
        if r.right - r.left < 400 or r.bottom - r.top < 300:
            return None
        return r.left, r.top, r.right - r.left, r.bottom - r.top
    except Exception:
        log.exception("Monitor detection failed")
        return None


class ThemedDialog:
    """Modal message / question / password box in the program's dark style."""

    @staticmethod
    def run(root, title, message, kind="info", buttons=("OK",), entry=False):
        return ThemedDialog(root, title, message, kind, buttons, entry).show()

    def __init__(self, root, title, message, kind, buttons, entry) -> None:
        self.result = None
        self.has_entry = entry
        stripe = {"info": C_ACCENT, "error": C_DANGER_HI, "ask": C_WARN}.get(kind, C_ACCENT)
        ui, disp = FONTS["ui"], FONTS["display"]
        win = self.win = tk.Toplevel(root)
        win.withdraw()
        win.title(title)
        win.configure(bg=C_BG)
        win.resizable(False, False)
        win.protocol("WM_DELETE_WINDOW", self._cancel)
        tk.Frame(win, bg=stripe, height=4).pack(fill="x")
        body = tk.Frame(win, bg=C_CARD, padx=28, pady=22)
        body.pack(fill="both", expand=True)
        tk.Label(body, text=title, bg=C_CARD, fg=C_TEXT, anchor="w",
                 font=(disp, 15, "bold")).pack(fill="x")
        tk.Label(body, text=message, bg=C_CARD, fg=C_MUTED, anchor="w", justify="left",
                 wraplength=440, font=(ui, 10)).pack(fill="x", pady=(8, 0))
        self.var = tk.StringVar()
        self.entry = None
        if entry:
            self.entry = tk.Entry(body, textvariable=self.var, show="*", bg=C_FIELD, fg=C_TEXT,
                                  insertbackground=C_TEXT, relief="flat", highlightthickness=1,
                                  highlightbackground=C_BORDER, highlightcolor=C_ACCENT,
                                  font=(ui, 12))
            self.entry.pack(fill="x", pady=(14, 0), ipady=6)
        row = tk.Frame(body, bg=C_CARD)
        row.pack(fill="x", pady=(20, 0))
        self.buttons = []
        for index, text in reversed(list(enumerate(buttons))):
            primary = index == 0
            btn = tk.Button(row, text=text, relief="flat", bd=0, padx=20, pady=7, cursor="hand2",
                            command=lambda i=index, t=text: self._press(i, t),
                            font=(ui, 10, "bold" if primary else "normal"),
                            bg=C_ACCENT if primary else C_RAISED, fg="#ffffff" if primary else C_TEXT,
                            activebackground=C_ACCENT_HI if primary else C_HOVER,
                            activeforeground="#ffffff")
            btn.pack(side="right", padx=(10, 0))
            self.buttons.append(btn)
        self.first_text = buttons[0]
        win.bind("<Return>", lambda _e: self._press(0, self.first_text))
        win.bind("<Escape>", lambda _e: self._cancel())

    def _press(self, index: int, text: str) -> None:
        if self.has_entry:
            self.result = self.var.get() if index == 0 else None
        else:
            self.result = text
        self.win.destroy()

    def _cancel(self) -> None:
        self.result = None
        self.win.destroy()

    def show(self):
        win = self.win
        win.update_idletasks()
        x = (win.winfo_screenwidth() - win.winfo_reqwidth()) // 2
        y = (win.winfo_screenheight() - win.winfo_reqheight()) // 3
        win.geometry(f"+{x}+{y}")
        win.deiconify()
        win.attributes("-topmost", True)
        win.lift()
        try:
            win.wait_visibility()
            win.grab_set()
            win.focus_force()
        except tk.TclError:
            pass
        (self.entry or win).focus_set()
        win.wait_window()
        return self.result


class CanvasButton:
    """Rounded button drawn on a canvas (Tk's own buttons cannot be rounded)."""

    def __init__(self, cv, cx, cy, w, h, label, font, command, fill, hover,
                 fg="#ffffff", outline="", enabled=True) -> None:
        self.cv, self.label, self.enabled, self.command = cv, label, enabled, command
        if not enabled:
            fill, hover, fg, outline = "#0b1530", "#0b1530", "#4a5d82", "#16264a"
        self.fill, self.hover = fill, hover
        x1, y1, x2, y2, r = cx - w // 2, cy - h // 2, cx + w // 2, cy + h // 2, h // 2
        points = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
                  x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
        self.shape = cv.create_polygon(points, smooth=True, fill=fill, outline=outline,
                                       width=2 if outline else 0)
        self.text = cv.create_text(cx, cy, text=label, fill=fg, font=font)
        if enabled:
            for item in (self.shape, self.text):
                cv.tag_bind(item, "<Enter>", self._enter)
                cv.tag_bind(item, "<Leave>", self._leave)
                cv.tag_bind(item, "<Button-1>", lambda _e: self.invoke())

    def _enter(self, _event) -> None:
        self.cv.itemconfigure(self.shape, fill=self.hover)
        self.cv.configure(cursor="hand2")

    def _leave(self, _event) -> None:
        self.cv.itemconfigure(self.shape, fill=self.fill)
        self.cv.configure(cursor="")

    def invoke(self) -> None:
        if self.enabled:
            self.command()


# --------------------------------------------------------------------------- #
# Full-screen warning overlay
# --------------------------------------------------------------------------- #
class WarningOverlay:
    """Full-screen countdown: a progress ring, large digits and postpone buttons.

    All sizes are in pixels and scale with the screen height, so the layout is the same
    on a 768 px laptop and a 4K monitor regardless of Windows display scaling.
    """

    def __init__(self, root, seconds, test, presets, cap, info,
                 on_postpone, on_now, on_expired, logo=None):
        """presets: minutes for the 3 buttons; cap: longest postpone allowed right now
        (0 = postponing not allowed); info: text about how much of the limit is used."""
        self.cap = cap
        self.on_postpone, self.on_now, self.on_expired = on_postpone, on_now, on_expired
        self.closed = False
        self.after_id = None
        self.total = float(max(1, seconds))
        self.deadline = time.monotonic() + seconds
        self.seconds_shown = seconds
        self.error_text = ""
        self.preset_buttons: list = []
        self._last_secs = None

        # Cover the monitor the person is working on (not always the primary one).
        mx, my, width, height = (monitor_under_pointer()
                                 or (0, 0, root.winfo_screenwidth(), root.winfo_screenheight()))
        unit = max(0.6, min(height / 1080.0, 1.8))

        def px(n):
            return max(1, int(n * unit))

        disp, ui = FONTS["display"], FONTS["ui"]
        win = self.win = tk.Toplevel(root)
        win.withdraw()
        win.title("Shutdown warning")
        win.configure(bg=C_BLACK)
        win.protocol("WM_DELETE_WINDOW", lambda: None)          # Alt+F4 / X do nothing
        win.geometry(f"{width}x{height}{mx:+d}{my:+d}")
        cv = self.cv = tk.Canvas(win, width=width, height=height, bg=C_BLACK,
                                 highlightthickness=0, bd=0)
        cv.pack(fill="both", expand=True)

        cx = width // 2
        ring_d, ring_w, ring_top = px(380), px(22), px(190)
        cy = ring_top + ring_d // 2

        # soft blue glow behind the ring
        steps, far = 40, int(max(width, height) * 0.62)
        for i in range(steps):
            t = i / (steps - 1)
            r = int(far * (1 - t) + px(130) * t)
            cv.create_oval(cx - r, cy - r, cx + r, cy + r, outline="",
                           fill=lerp_color(C_BLACK, "#0f2a57", t ** 2.0))

        if logo is not None:
            cv.create_image(px(44), px(36), image=logo, anchor="nw")
        cv.create_text(px(44) + 80, px(36) + 32, text="Shutdown Scheduler", anchor="w",
                       fill=C_MUTED, font=(disp, -px(24), "bold"))

        head = "Preview: nothing will be shut down" if test else "This PC is about to shut down"
        cv.create_text(cx, px(128), text=head, fill=C_CYAN if test else C_TEXT,
                       font=(disp, -px(40), "bold"))

        bbox = (cx - ring_d // 2 + ring_w // 2, ring_top + ring_w // 2,
                cx + ring_d // 2 - ring_w // 2, ring_top + ring_d - ring_w // 2)
        cv.create_oval(*bbox, outline="#12264a", width=ring_w)
        self.glow_arc = cv.create_arc(*bbox, start=90, extent=-359.9, style="arc",
                                      outline="#0e2a55", width=ring_w + px(16))
        self.arc = cv.create_arc(*bbox, start=90, extent=-359.9, style="arc",
                                 outline=C_CYAN, width=ring_w)
        self.num = cv.create_text(cx, cy - px(14), text=str(seconds), fill=C_TEXT,
                                  font=(disp, -px(150), "bold"))
        cv.create_text(cx, cy + px(98), text="seconds", fill=C_MUTED, font=(ui, -px(26)))
        cv.create_text(cx, ring_top + ring_d + px(40), text="Save your work now.",
                       fill=C_TEXT, font=(ui, -px(28)))

        y = ring_top + ring_d + px(104)
        ask = ("Need more time? Postpone the shutdown." if cap > 0
               else "Postponing is not available any more. The limit is reached.")
        cv.create_text(cx, y, text=ask, fill=C_TEXT if cap > 0 else C_WARN,
                       font=(disp, -px(28), "bold"))

        y += px(64)
        bw, bh, gap = px(200), px(64), px(20)
        left = cx - (len(presets) * bw + (len(presets) - 1) * gap) // 2 + bw // 2
        for i, minutes in enumerate(presets):
            self.preset_buttons.append(CanvasButton(
                cv, left + i * (bw + gap), y, bw, bh, fmt_postpone(minutes),
                (disp, -px(24), "bold"), lambda m=minutes: self._finish(self.on_postpone, m),
                fill="#14305f", hover="#1f4a8f", fg=C_TEXT, outline="#2b5aa8",
                enabled=minutes <= cap))

        y += px(90)
        can_type = cap > 0
        label_text = "or type minutes:"
        label_w = tkfont.Font(root=root, family=ui, size=-px(26)).measure(label_text)
        entry_w, btn_w, gap2 = px(120), px(180), px(20)
        sx = cx - (label_w + gap2 + entry_w + gap2 + btn_w) // 2
        cv.create_text(sx, y, text=label_text, anchor="w", fill=C_MUTED, font=(ui, -px(26)))
        self.custom_var = tk.StringVar()
        self.entry = tk.Entry(win, textvariable=self.custom_var, justify="center",
                              state="normal" if can_type else "disabled", relief="flat",
                              bg=C_FIELD, fg=C_TEXT, insertbackground=C_TEXT,
                              disabledbackground="#0b1530", highlightthickness=2,
                              highlightbackground=C_BORDER, highlightcolor=C_ACCENT,
                              font=(ui, -px(28)))
        cv.create_window(sx + label_w + gap2 + entry_w // 2, y, window=self.entry,
                         width=entry_w, height=px(50))
        self.entry.bind("<Return>", lambda _e: self._postpone_custom())
        self.custom_button = CanvasButton(
            cv, sx + label_w + gap2 + entry_w + gap2 + btn_w // 2, y, btn_w, px(54), "Postpone",
            (disp, -px(23), "bold"), self._postpone_custom, fill=C_ACCENT, hover=C_ACCENT_HI,
            enabled=can_type)

        y += px(58)
        if info:
            cv.create_text(cx, y, text=info, fill=C_MUTED, font=(ui, -px(22)))
        y += px(34)
        self.error_item = cv.create_text(cx, y, text="", fill=C_WARN, font=(ui, -px(24), "bold"))

        CanvasButton(cv, cx, height - px(58), px(250), px(50), "Shut down now",
                     (ui, -px(21)), lambda: self._finish(self.on_now),
                     fill="#2a0d12", hover="#5a1620", fg="#ffb3b8", outline="#7a1d28")

        win.deiconify()
        try:
            win.attributes("-fullscreen", True)
        except tk.TclError:
            pass
        win.attributes("-topmost", True)
        win.lift()
        win.focus_force()
        if can_type:
            self.entry.focus_set()
        self._beep()
        self._tick()

    def set_error(self, text: str) -> None:
        self.error_text = text
        self.cv.itemconfigure(self.error_item, text=text)

    def _beep(self) -> None:
        try:
            if IS_WINDOWS:
                winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
            else:
                self.win.bell()
        except Exception:
            pass

    def _postpone_custom(self) -> None:
        if self.cap <= 0:
            return
        try:
            minutes = int(self.custom_var.get().strip())
        except ValueError:
            self.set_error(f"Type a whole number of minutes (1 to {self.cap}).")
            return
        if not 1 <= minutes <= self.cap:
            self.set_error(f"Allowed right now: 1 to {self.cap} minutes.")
            return
        self._finish(self.on_postpone, minutes)

    def _tick(self) -> None:
        if self.closed:
            return
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            self._finish(self.on_expired)
            return
        secs = int(math.ceil(remaining))
        fraction = max(0.0, min(1.0, remaining / self.total))
        color = ring_color(fraction)
        extent = -max(0.5, 359.9 * fraction)
        try:
            self.cv.itemconfigure(self.arc, extent=extent, outline=color)
            self.cv.itemconfigure(self.glow_arc, extent=extent, outline=lerp_color(C_BLACK, color, 0.22))
            if secs != self._last_secs:
                self._last_secs = secs
                self.seconds_shown = secs
                self.cv.itemconfigure(self.num, text=str(secs),
                                      fill="#ff9aa2" if secs <= 10 else C_TEXT)
                if secs <= 10:
                    self._beep()
            self.win.lift()
            self.win.attributes("-topmost", True)
            if self.win.focus_displayof() is None:             # another app stole the focus
                self.win.focus_force()
                if self.cap > 0:
                    self.entry.focus_set()
        except tk.TclError:
            pass
        self.after_id = self.win.after(200, self._tick)

    def _finish(self, callback, *args) -> None:
        if self.closed:
            return
        self.closed = True
        if self.after_id is not None:
            try:
                self.win.after_cancel(self.after_id)
            except tk.TclError:
                pass
        try:
            self.win.destroy()
        except tk.TclError:
            pass
        callback(*args)


# --------------------------------------------------------------------------- #
# Main application
# --------------------------------------------------------------------------- #
class App:
    OK_COLOR = C_OK
    BAD_COLOR = C_BAD

    def __init__(self, args, instance: SingleInstance) -> None:
        self.args = args
        self.instance = instance
        self.cfg = Config()
        self.admin = is_admin()
        self.overlay: WarningOverlay | None = None
        self.view = ""                       # "setup" | "lock" | "dashboard"
        self.fail_count = 0
        self.locked_until = 0.0
        self.lockout_msg_shown = False
        self.last_touch = time.monotonic()
        self.modal_depth = 0
        self.hint_shown = False
        self.shutdown_busy_until = 0.0
        self.closing = False
        self.result_queue: queue.Queue = queue.Queue()
        self.msg_lbl = None
        self.lbl_left = None
        self.lbl_when = None

        self.root = tk.Tk()
        self.root.title(self._title())
        self.root.resizable(False, False)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close_window)
        self.root.report_callback_exception = self._on_tk_error
        for seq in ("<Any-KeyPress>", "<Any-ButtonPress>", "<Motion>"):
            self.root.bind_all(seq, self._touch, add="+")

        init_fonts(self.root)
        self.images = init_images(self.root)
        apply_theme(self.root)
        if "icon" in self.images:
            try:
                self.root.iconphoto(True, self.images["icon"])      # window + taskbar icon
            except tk.TclError:
                pass
        self.root.minsize(540, 0)
        self.sub_var = tk.StringVar()
        self._build_header()
        self.container = ttk.Frame(self.root, style="Bg.TFrame", padding=(18, 16))
        self.container.pack(fill="both", expand=True)

        # Tk variables shared by the views
        self.msg_var = tk.StringVar()
        self.var_mode = tk.StringVar()
        self.var_hour = tk.StringVar()
        self.var_minute = tk.StringVar()
        self.var_repeat = tk.BooleanVar()
        self.var_after = tk.StringVar()
        self.var_always = tk.BooleanVar()
        self.var_force = tk.BooleanVar()
        self.var_autostart = tk.BooleanVar()
        self.limit_vars = {key: tk.StringVar() for key in FIELD_LABELS}
        self.var_lock = tk.StringVar()
        self.var_cur = tk.StringVar()
        self.var_new = tk.StringVar()
        self.var_conf = tk.StringVar()

        if IS_WINDOWS and self.cfg["autostart"]:
            set_autostart(True)              # self-heal if the exe was moved

        if not self.cfg["pw_hash"]:
            self.show_setup()
        else:
            self.show_lock()
            if self.args.background and not self.args.elevated:
                self.root.withdraw()         # run silently in the background

    # ------------------------------------------------------------------ utils
    def _title(self, suffix: str = "") -> str:
        title = APP_TITLE + (f" - {suffix}" if suffix else "")
        if self.args.dry_run:
            title += " [DRY RUN]"
        if self.admin:
            title += " (Administrator)"
        return title

    def _on_tk_error(self, exc, val, tb) -> None:
        log.error("Tk callback error", exc_info=(exc, val, tb))

    def _touch(self, _event=None) -> None:
        self.last_touch = time.monotonic()

    def _clear(self) -> None:
        for child in self.container.winfo_children():
            child.destroy()
        self.msg_lbl = None
        self.lbl_left = None
        self.lbl_when = None
        self.msg_var.set("")

    def _build_header(self) -> None:
        """Black title bar with the program icon; stays while the views below change."""
        bar = ttk.Frame(self.root, style="Header.TFrame", padding=(18, 12))
        bar.pack(fill="x")
        if "logo" in self.images:
            ttk.Label(bar, image=self.images["logo"], style="Header.TLabel").pack(side="left")
        box = ttk.Frame(bar, style="Header.TFrame")
        box.pack(side="left", padx=(14, 0))
        ttk.Label(box, text="Shutdown Scheduler", style="HeaderTitle.TLabel").pack(anchor="w")
        ttk.Label(box, textvariable=self.sub_var, style="HeaderSub.TLabel").pack(anchor="w")
        tk.Frame(self.root, height=2, bg=C_ACCENT).pack(fill="x")

    def _logo(self, parent) -> None:
        if "icon" in self.images:
            ttk.Label(parent, image=self.images["icon"]).pack(pady=(0, 10))

    def _add_message_label(self, parent, center: bool = False) -> None:
        self.msg_lbl = ttk.Label(parent, textvariable=self.msg_var, style="Bg.TLabel", wraplength=560,
                                 justify="center" if center else "left",
                                 anchor="center" if center else "w")
        self.msg_lbl.pack(fill="x", pady=(10, 0))

    def _set_msg(self, text: str, ok: bool = True) -> None:
        self.msg_var.set(text)
        if self.msg_lbl is not None:
            try:
                self.msg_lbl.configure(foreground=self.OK_COLOR if ok else self.BAD_COLOR)
            except tk.TclError:
                pass

    # Modal helpers: while one is open the dashboard must not auto-lock.
    def _modal(self, func, *args, **kwargs):
        self.modal_depth += 1
        try:
            return func(*args, **kwargs)
        finally:
            self.modal_depth -= 1

    def _info(self, title: str, text: str) -> None:
        self._modal(ThemedDialog.run, self.root, title, text, "info", ("OK",))

    def _error(self, title: str, text: str) -> None:
        self._modal(ThemedDialog.run, self.root, title, text, "error", ("OK",))

    def _ask_yes_no(self, title: str, text: str) -> bool:
        return self._modal(ThemedDialog.run, self.root, title, text, "ask", ("Yes", "No")) == "Yes"

    def _ask_password(self, title: str, prompt: str):
        """Typed password, or None if the box was cancelled."""
        return self._modal(ThemedDialog.run, self.root, title, prompt, "ask", ("OK", "Cancel"), True)

    # -------------------------------------------------------------- password
    def _verify_with_lockout(self, password: str) -> tuple[bool, str]:
        """Check the password; escalating delay after repeated failures."""
        remaining = self.locked_until - time.monotonic()
        if remaining > 0:
            return False, f"Too many wrong attempts. Try again in {int(math.ceil(remaining))} s."
        if verify_password(password, self.cfg["pw_salt"], self.cfg["pw_hash"], self.cfg["pw_iter"]):
            self.fail_count = 0
            return True, ""
        self.fail_count += 1
        log.warning("Wrong password entered (%d in a row)", self.fail_count)
        max_attempts, base = self.cfg["max_attempts"], self.cfg["lockout_seconds"]
        if self.fail_count >= max_attempts:
            delay = min(base * 2 ** min(self.fail_count - max_attempts, 20), max(600, base))
            self.locked_until = time.monotonic() + delay
            return False, f"Wrong password. Locked for {delay} seconds."
        left = max_attempts - self.fail_count
        return False, f"Wrong password ({left} attempt(s) left before a temporary lock-out)."

    # ----------------------------------------------------------------- views
    def show_setup(self) -> None:
        self._clear()
        self.view = "setup"
        self.root.title(self._title("First start"))
        self.sub_var.set("Create a password to get started")
        for var in (self.var_new, self.var_conf):
            var.set("")
        card = ttk.Frame(self.container, padding=28)
        card.pack(pady=(4, 0))
        self._logo(card)
        ttk.Label(card, text="Create a password", style="Title.TLabel").pack()
        ttk.Label(
            card, style="Muted.TLabel", wraplength=380, justify="center",
            text=("The password protects the dashboard: changing the schedule and limits, and quitting. "
                  "Use at least %d characters. If you forget it, delete config.json in "
                  "%%APPDATA%%\\%s and start over." % (self.cfg["min_password"], APP_NAME)),
        ).pack(pady=(6, 16))
        ttk.Label(card, text="New password").pack(anchor="w")
        first = ttk.Entry(card, show="*", textvariable=self.var_new, width=34, font=(FONTS["ui"], 11))
        first.pack(fill="x", pady=(2, 10))
        ttk.Label(card, text="Repeat password").pack(anchor="w")
        second = ttk.Entry(card, show="*", textvariable=self.var_conf, width=34, font=(FONTS["ui"], 11))
        second.pack(fill="x", pady=(2, 0))
        second.bind("<Return>", lambda _e: self.create_password())
        ttk.Button(card, text="Create password", style="Accent.TButton",
                   command=self.create_password).pack(fill="x", pady=(18, 0))
        self._add_message_label(self.container, center=True)
        first.focus_set()

    def create_password(self) -> None:
        new, conf = self.var_new.get(), self.var_conf.get()
        minimum = self.cfg["min_password"]
        if len(new) < minimum:
            self._set_msg(f"The password must have at least {minimum} characters.", False)
            return
        if new != conf:
            self._set_msg("The two passwords do not match.", False)
            return
        salt, digest = hash_password(new)
        self.cfg["pw_salt"], self.cfg["pw_hash"], self.cfg["pw_iter"] = salt, digest, PBKDF2_ITERATIONS
        if not self.cfg.save():
            self.cfg["pw_hash"] = ""
            self._set_msg("Could not save the settings file. Check the disk / folder permissions.", False)
            return
        log.info("Password created")
        self.show_dashboard()

    def show_lock(self, reason: str = "") -> None:
        self._clear()
        self.view = "lock"
        self.root.title(self._title("Locked"))
        self.sub_var.set("Locked")
        self.var_lock.set("")
        card = ttk.Frame(self.container, padding=28)
        card.pack(pady=(4, 0))
        self._logo(card)
        ttk.Label(card, text="Locked", style="Title.TLabel").pack()
        ttk.Label(card, text="Enter the password to open the dashboard.",
                  style="Muted.TLabel").pack(pady=(4, 14))
        entry = ttk.Entry(card, show="*", textvariable=self.var_lock, width=30, font=(FONTS["ui"], 11))
        entry.pack(fill="x")
        entry.bind("<Return>", lambda _e: self.try_unlock())
        ttk.Button(card, text="Unlock", style="Accent.TButton",
                   command=self.try_unlock).pack(fill="x", pady=(14, 0))
        self._add_message_label(self.container, center=True)
        self._set_msg(reason, True)
        entry.focus_set()

    def try_unlock(self) -> None:
        ok, msg = self._verify_with_lockout(self.var_lock.get())
        if not ok:
            self.var_lock.set("")
            self._set_msg(msg, False)
            return
        self._touch()
        self.show_dashboard()

    def show_dashboard(self) -> None:
        self._clear()
        self.view = "dashboard"
        self.root.title(self._title("Dashboard"))
        self.sub_var.set("Dashboard")
        self._load_vars()
        f = self.container
        ui = FONTS["ui"]

        notebook = ttk.Notebook(f)
        notebook.pack(fill="both", expand=True)
        tab_sched, tab_limits, tab_sec = (ttk.Frame(notebook, padding=18) for _ in range(3))
        notebook.add(tab_sched, text="Schedule")
        notebook.add(tab_limits, text="Limits")
        notebook.add(tab_sec, text="Security & options")

        # ============================== tab 1: schedule ==============================
        box = ttk.LabelFrame(tab_sched, text="Next shutdown", padding=14)
        box.pack(fill="x")
        self.lbl_left = ttk.Label(box, text="--:--:--", style="Big.TLabel")
        self.lbl_left.pack(anchor="w")
        self.lbl_when = ttk.Label(box, text="", style="Muted.TLabel")
        self.lbl_when.pack(anchor="w", pady=(2, 0))
        if self.admin:
            admin_text = "Running with administrator rights."
        else:
            admin_text = ("Running as a standard user. Shutdown normally works anyway. If it fails "
                          "with 'access denied', restart as administrator.")
        ttk.Label(box, text=admin_text, style="Muted.TLabel", wraplength=560,
                  justify="left").pack(anchor="w", pady=(10, 0))
        if IS_WINDOWS and not self.admin:
            ttk.Button(box, text="Restart as administrator",
                       command=self.restart_as_admin).pack(anchor="w", pady=(8, 0))

        sch = ttk.LabelFrame(tab_sched, text="Schedule", padding=14)
        sch.pack(fill="x", pady=(14, 0))
        row = ttk.Frame(sch)
        row.pack(fill="x")
        ttk.Radiobutton(row, text="Shut down at", variable=self.var_mode, value="at").pack(side="left")
        ttk.Spinbox(row, from_=0, to=23, width=3, wrap=True, format="%02.0f", font=(ui, 11),
                    textvariable=self.var_hour).pack(side="left", padx=(10, 0))
        ttk.Label(row, text=":").pack(side="left", padx=2)
        ttk.Spinbox(row, from_=0, to=59, width=3, wrap=True, format="%02.0f", font=(ui, 11),
                    textvariable=self.var_minute).pack(side="left")
        ttk.Checkbutton(row, text="Repeat every day", variable=self.var_repeat).pack(side="left", padx=(18, 0))
        row = ttk.Frame(sch)
        row.pack(fill="x", pady=(10, 0))
        ttk.Radiobutton(row, text="Shut down in", variable=self.var_mode, value="after").pack(side="left")
        ttk.Spinbox(row, from_=1, to=10080, width=6, font=(ui, 11),
                    textvariable=self.var_after).pack(side="left", padx=(10, 6))
        ttk.Label(row, text="minutes from now").pack(side="left")
        row = ttk.Frame(sch)
        row.pack(fill="x", pady=(14, 0))
        ttk.Button(row, text="Start / update schedule", style="Accent.TButton",
                   command=self.apply_schedule).pack(side="left")
        ttk.Button(row, text="Cancel schedule", command=self.cancel_schedule).pack(side="left", padx=8)

        # ============================== tab 2: limits ==============================
        grid = ttk.Frame(tab_limits)
        grid.pack(fill="x")
        self._build_fields(grid, LIMIT_FIELDS["limits"])
        ttk.Label(tab_limits, style="Muted.TLabel", wraplength=560, justify="left",
                  text=("Postpone limits are counted per shutdown. They start again after the shutdown "
                        "has happened, when you change or cancel the schedule, or after 24 hours. "
                        "Click Save settings to apply changes.")).pack(anchor="w", pady=(14, 0))

        # ============================== tab 3: security & options ==============================
        grid = ttk.Frame(tab_sec)
        grid.pack(fill="x")
        self._build_fields(grid, LIMIT_FIELDS["security"])

        opt = ttk.LabelFrame(tab_sec, text="Options", padding=12)
        opt.pack(fill="x", pady=(14, 0))
        ttk.Checkbutton(opt, text="Always show the warning, even if the PC looks idle "
                                  "(for example while watching a video)",
                        variable=self.var_always).pack(anchor="w", pady=2)
        ttk.Checkbutton(opt, text="Force-close programs that block the shutdown "
                                  "(unsaved work may be lost)",
                        variable=self.var_force).pack(anchor="w", pady=2)
        ttk.Checkbutton(opt, text="Start with Windows (runs hidden in the background)",
                        variable=self.var_autostart).pack(anchor="w", pady=2)

        pw = ttk.LabelFrame(tab_sec, text="Change password", padding=12)
        pw.pack(fill="x", pady=(14, 0))
        grid = ttk.Frame(pw)
        grid.pack(fill="x")
        for r, (text, var) in enumerate((("Current", self.var_cur), ("New", self.var_new),
                                         ("Repeat new", self.var_conf))):
            ttk.Label(grid, text=text, width=11).grid(row=r, column=0, sticky="w", pady=2)
            ttk.Entry(grid, show="*", textvariable=var, width=26,
                      font=(ui, 10)).grid(row=r, column=1, sticky="w", pady=2)
        ttk.Button(grid, text="Change password", command=self.change_password).grid(
            row=0, column=2, rowspan=3, padx=14)

        # ============================== bottom buttons ==============================
        row = ttk.Frame(f, style="Bg.TFrame")
        row.pack(fill="x", pady=(14, 0))
        ttk.Button(row, text="Save settings", style="Accent.TButton",
                   command=self.save_settings).pack(side="left")
        ttk.Button(row, text="Preview warning",
                   command=lambda: self.show_warning(test=True)).pack(side="left", padx=8)
        ttk.Button(row, text="Lock now", command=lambda: self.show_lock("Locked.")).pack(side="left")
        ttk.Button(row, text="Hide (keep running)", command=self.hide_window).pack(side="left", padx=8)
        ttk.Button(row, text="Quit program", style="Danger.TButton",
                   command=self.request_quit).pack(side="right")
        self._add_message_label(f)
        self._update_status()

    def _build_fields(self, parent, fields) -> None:
        """Grid of 'label [spinbox] hint' rows bound to self.limit_vars."""
        for r, (key, label, hint) in enumerate(fields):
            low, high = RANGES[key]
            ttk.Label(parent, text=label).grid(row=r, column=0, sticky="w", pady=4)
            ttk.Spinbox(parent, from_=low, to=high, width=7, font=(FONTS["ui"], 11),
                        textvariable=self.limit_vars[key]).grid(row=r, column=1, sticky="w", padx=12)
            ttk.Label(parent, text=hint, style="Muted.TLabel").grid(row=r, column=2, sticky="w")

    def _load_vars(self) -> None:
        c = self.cfg
        self.var_mode.set(c["mode"])
        self.var_hour.set(f"{c['hour']:02d}")
        self.var_minute.set(f"{c['minute']:02d}")
        self.var_repeat.set(c["repeat_daily"])
        self.var_after.set(str(c["after_minutes"]))
        for key, var in self.limit_vars.items():
            var.set(str(c[key]))
        self.var_always.set(c["always_warn"])
        self.var_force.set(c["force_close"])
        self.var_autostart.set(c["autostart"])
        for var in (self.var_cur, self.var_new, self.var_conf):
            var.set("")

    @staticmethod
    def _read_int(var, low: int, high: int, label: str) -> int:
        try:
            value = int(str(var.get()).strip())
        except ValueError:
            raise ValueError(f"{label} must be a whole number.") from None
        if not low <= value <= high:
            raise ValueError(f"{label} must be between {low} and {high}.")
        return value

    # ---------------------------------------------------------- dashboard actions
    def apply_schedule(self) -> None:
        try:
            mode = self.var_mode.get()
            if mode == "at":
                hour = self._read_int(self.var_hour, 0, 23, "Hour")
                minute = self._read_int(self.var_minute, 0, 59, "Minute")
                target = next_occurrence(hour, minute).timestamp()
                self.cfg["hour"], self.cfg["minute"] = hour, minute
                self.cfg["repeat_daily"] = bool(self.var_repeat.get())
            else:
                minutes = self._read_int(self.var_after, 1, 7 * 24 * 60, "Minutes")
                target = time.time() + minutes * 60
                self.cfg["after_minutes"] = minutes
                self.cfg["repeat_daily"] = False
        except ValueError as exc:
            self._set_msg(str(exc), False)
            return
        self.cfg["mode"], self.cfg["target_ts"], self.cfg["enabled"] = mode, target, True
        self._reset_postpone()
        saved = self.cfg.save()
        when = datetime.fromtimestamp(target).strftime("%a %d %b %Y, %H:%M")
        log.info("Shutdown scheduled for %s", when)
        if saved:
            self._set_msg(f"Shutdown scheduled for {when}.", True)
        else:
            self._set_msg(f"Scheduled for {when}, but the settings file could not be saved "
                          "(the schedule will be lost if the program closes).", False)
        self._update_status()

    def cancel_schedule(self) -> None:
        self.cfg["enabled"], self.cfg["target_ts"] = False, 0.0
        self._reset_postpone()
        self.cfg.save()
        log.info("Schedule cancelled")
        self._set_msg("Schedule cancelled.", True)
        self._update_status()

    def save_settings(self) -> None:
        """Validate and store every limit and option from the Limits / Security tabs."""
        values = {}
        try:
            for key, var in self.limit_vars.items():
                low, high = RANGES[key]
                values[key] = self._read_int(var, low, high, FIELD_LABELS[key])
        except ValueError as exc:
            self._set_msg(str(exc), False)
            return
        self.cfg.data.update(values)
        self.cfg["always_warn"] = bool(self.var_always.get())
        self.cfg["force_close"] = bool(self.var_force.get())
        want = bool(self.var_autostart.get())
        problem = ""
        if want != self.cfg["autostart"] or want:
            ok, err = set_autostart(want)
            if not ok:
                problem = f" Auto-start could not be changed: {err}"
                want = bool(self.cfg["autostart"])                 # keep the previous state
                self.var_autostart.set(want)
        self.cfg["autostart"] = want
        saved = self.cfg.save()
        log.info("Settings saved")
        if saved and not problem:
            self._set_msg("Settings saved. Limits apply from the next warning.", True)
        else:
            self._set_msg(("Settings saved." if saved else "Settings could not be written to disk.")
                          + problem, False)

    def change_password(self) -> None:
        ok, msg = self._verify_with_lockout(self.var_cur.get())
        if not ok:
            self._set_msg(msg, False)
            return
        new, conf = self.var_new.get(), self.var_conf.get()
        minimum = self.cfg["min_password"]
        if len(new) < minimum:
            self._set_msg(f"The new password must have at least {minimum} characters.", False)
            return
        if new != conf:
            self._set_msg("The two new passwords do not match.", False)
            return
        old = (self.cfg["pw_salt"], self.cfg["pw_hash"], self.cfg["pw_iter"])
        salt, digest = hash_password(new)
        self.cfg["pw_salt"], self.cfg["pw_hash"], self.cfg["pw_iter"] = salt, digest, PBKDF2_ITERATIONS
        if not self.cfg.save():
            self.cfg["pw_salt"], self.cfg["pw_hash"], self.cfg["pw_iter"] = old
            self._set_msg("Could not save the new password. The old one is still active.", False)
            return
        for var in (self.var_cur, self.var_new, self.var_conf):
            var.set("")
        log.info("Password changed")
        self._set_msg("Password changed.", True)

    def restart_as_admin(self) -> None:
        if not self._ask_yes_no("Restart as administrator",
                                "Windows will ask for permission, then a new copy of the "
                                "scheduler starts with administrator rights and this one closes.\n\n"
                                "Continue?"):
            return
        self.cfg.save()
        extra = ["--elevated"] + (["--dry-run"] if self.args.dry_run else [])
        if relaunch_as_admin(extra):
            log.info("Restarting with administrator rights")
            self.quit_app()
        else:
            self._set_msg("Elevation was cancelled or failed. Nothing was changed.", False)

    def request_quit(self) -> None:
        pw = self._ask_password("Quit Shutdown Scheduler",
                                "Enter the password to close the scheduler.\n"
                                "Scheduled shutdowns will no longer happen.")
        if pw is None:
            return
        ok, msg = self._verify_with_lockout(pw)
        if not ok:
            self._set_msg(msg, False)
            return
        self.quit_app()

    # --------------------------------------------------------- window handling
    def show_window(self) -> None:
        if self.root.state() == "withdrawn" and self.view == "dashboard":
            self.show_lock()                 # never reveal the dashboard without the password
        self.root.deiconify()
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after(400, lambda: self._safe_topmost_off())
        self.root.focus_force()
        self._touch()

    def _safe_topmost_off(self) -> None:
        try:
            self.root.attributes("-topmost", False)
        except tk.TclError:
            pass

    def hide_window(self) -> None:
        if self.view == "setup":             # no password yet: nothing to protect or run
            self.quit_app()
            return
        if self.view == "dashboard":
            self.show_lock()
        self.root.withdraw()

    def on_close_window(self) -> None:
        """The X button hides the program instead of ending it."""
        if self.view == "setup":
            self.quit_app()
            return
        self.hide_window()
        if not self.hint_shown:
            self.hint_shown = True
            self._info(APP_TITLE,
                       "Shutdown Scheduler keeps running in the background.\n\n"
                       "Start the program again to open the (locked) dashboard.")

    def quit_app(self) -> None:
        if self.closing:
            return
        self.closing = True
        log.info("Shutdown Scheduler exiting")
        try:
            self.root.destroy()
        except tk.TclError:
            pass

    # ----------------------------------------------------------- timer / logic
    def run(self) -> None:
        self.root.after(1000, self._tick)
        self.root.mainloop()

    def _tick(self) -> None:
        if self.closing:
            return
        try:
            self._handle_ipc()
            self._handle_shutdown_results()
            self._update_lock_message()
            self._check_auto_lock()
            self._update_status()
            self._check_schedule()
        except Exception:
            log.exception("Error in scheduler tick")
        finally:
            if not self.closing:
                self.root.after(1000, self._tick)

    def _handle_ipc(self) -> None:
        show = False
        while True:
            try:
                if self.instance.events.get_nowait() == "show":
                    show = True
            except queue.Empty:
                break
        if show:
            log.info("Second launch detected - showing the window")
            self.show_window()

    def _handle_shutdown_results(self) -> None:
        while True:
            try:
                ok, msg = self.result_queue.get_nowait()
            except queue.Empty:
                return
            if ok:
                log.info(msg)
                if self.args.dry_run:
                    # Deferred: a modal box inside the tick would pause the scheduler timer.
                    self.root.after(50, self._info, "Dry run", msg)
            else:
                log.error("Shutdown failed: %s", msg)
                self.shutdown_busy_until = 0.0
                self.root.after(50, self._error, "Shutdown failed", msg)

    def _update_lock_message(self) -> None:
        if self.view != "lock":
            return
        remaining = self.locked_until - time.monotonic()
        if remaining > 0:
            self.lockout_msg_shown = True
            self._set_msg(f"Too many wrong attempts. Try again in {int(math.ceil(remaining))} s.", False)
        elif self.lockout_msg_shown:
            self.lockout_msg_shown = False
            self._set_msg("", True)

    def _check_auto_lock(self) -> None:
        if self.view != "dashboard" or self.modal_depth > 0 or self.overlay is not None:
            return
        limit = self.cfg["autolock_seconds"]
        if time.monotonic() - self.last_touch > limit:
            log.info("Dashboard auto-locked")
            self.show_lock("Locked after %d seconds of inactivity." % limit)

    def _update_status(self) -> None:
        if self.view != "dashboard" or self.lbl_left is None:
            return
        if self.cfg["enabled"] and self.cfg["target_ts"] > 0:
            target = self.cfg["target_ts"]
            remaining = target - time.time()
            when = datetime.fromtimestamp(target).strftime("%a %d %b %Y, %H:%M")
            if remaining > 0:
                left, text = fmt_hms(remaining), when
            else:
                left, text = "00:00:00", when + " (due now)"
        else:
            left, text = "--:--:--", "No shutdown is scheduled."
        try:
            self.lbl_left.configure(text=left)
            self.lbl_when.configure(text=text)
        except tk.TclError:
            pass

    def _advance_schedule(self) -> None:
        """Called when a schedule fires (or is missed): plan the next run or switch off."""
        if self.cfg["mode"] == "at" and self.cfg["repeat_daily"]:
            soon = datetime.now() + timedelta(minutes=1)
            nxt = next_occurrence(self.cfg["hour"], self.cfg["minute"], after=soon)
            self.cfg["target_ts"] = nxt.timestamp()
        else:
            self.cfg["enabled"], self.cfg["target_ts"] = False, 0.0
        self.cfg.save()

    def _check_schedule(self) -> None:
        if self.overlay is not None or time.monotonic() < self.shutdown_busy_until:
            return
        if not self.cfg["enabled"]:
            return
        target, now = self.cfg["target_ts"], time.time()
        if target <= 0 or now < target:
            return
        if now - target > self.cfg["grace_minutes"] * 60:
            # e.g. the PC was asleep / off at the scheduled time: never shut down "late" by surprise
            log.warning("Scheduled time was missed by %s - skipping", fmt_hms(now - target))
            self._reset_postpone()
            self._advance_schedule()
            return
        log.info("Scheduled time reached")
        self._advance_schedule()          # first, so a failing shutdown cannot loop forever
        idle = get_idle_seconds()
        in_use = self.cfg["always_warn"] or idle < self.cfg["idle_minutes"] * 60
        if in_use:
            log.info("PC is in use (idle %.0f s) - showing warning", idle)
            self.show_warning(test=False)
        else:
            log.info("PC is idle (%.0f s) - shutting down without warning", idle)
            self._start_shutdown()

    def _reset_postpone(self) -> None:
        """Forget how much postponing was used (caller saves the config)."""
        self.cfg["pp_count"], self.cfg["pp_total"], self.cfg["pp_started_ts"] = 0, 0, 0.0

    def _postpone_allowance(self) -> int:
        """Longest postpone (minutes) the user may still choose right now; 0 = none."""
        c = self.cfg
        if c["pp_started_ts"] > 0 and time.time() - c["pp_started_ts"] > 24 * 3600:
            self._reset_postpone()
        if c["max_postpones"] > 0 and c["pp_count"] >= c["max_postpones"]:
            return 0
        cap = c["max_single"]
        if c["max_total"] > 0:
            cap = min(cap, c["max_total"] - c["pp_total"])
        return max(0, cap)

    def _postpone_info(self) -> str:
        c, parts = self.cfg, []
        if c["max_postpones"] > 0:
            parts.append(f"Postpones used: {c['pp_count']} of {c['max_postpones']}")
        if c["max_total"] > 0:
            parts.append(f"Minutes used: {c['pp_total']} of {c['max_total']}")
        return "     |     ".join(parts)

    def show_warning(self, test: bool = False) -> None:
        if self.overlay is not None:
            return
        c = self.cfg
        presets = [c["preset1"], c["preset2"], c["preset3"]]
        cap = self._postpone_allowance()

        def postpone(minutes: int) -> None:
            self.overlay = None
            if test:
                return
            minutes = min(minutes, self._postpone_allowance())     # never exceed the limits
            if minutes <= 0:
                self._start_shutdown()
                return
            c["pp_count"] += 1
            c["pp_total"] += minutes
            if c["pp_started_ts"] <= 0:
                c["pp_started_ts"] = time.time()
            c["enabled"] = True
            c["target_ts"] = time.time() + minutes * 60
            c.save()
            log.info("Shutdown postponed by %d minutes (%d used)", minutes, c["pp_count"])

        def shut_now() -> None:
            self.overlay = None
            if test:
                self.root.after(50, self._info, "Preview",
                                "This was only a preview - nothing was shut down.")
            else:
                self._start_shutdown()

        self.overlay = WarningOverlay(self.root, c["warning_seconds"], test, presets, cap,
                                      self._postpone_info(), postpone, shut_now, shut_now,
                                      logo=self.images.get("logo"))

    def _start_shutdown(self) -> None:
        if time.monotonic() < self.shutdown_busy_until:
            return
        self.shutdown_busy_until = time.monotonic() + SHUTDOWN_BUSY_SECONDS
        self._reset_postpone()                # this shutdown is happening - start counting afresh
        self.cfg.save()
        force, dry = bool(self.cfg["force_close"]), bool(self.args.dry_run)
        log.info("Running shutdown (force=%s, dry_run=%s)", force, dry)

        def worker() -> None:
            try:
                result = run_shutdown(force, dry)
            except Exception as exc:            # never let the thread die silently
                log.exception("Shutdown worker crashed")
                result = (False, f"Unexpected error: {exc}")
            self.result_queue.put(result)

        threading.Thread(target=worker, name="shutdown", daemon=True).start()


# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #
def parse_args():
    parser = argparse.ArgumentParser(description=APP_TITLE, add_help=False)   # --help would crash without a console
    parser.add_argument("--background", action="store_true", help="start hidden")
    parser.add_argument("--elevated", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--dry-run", action="store_true", help="never really shut down")
    args, _unknown = parser.parse_known_args()    # never exit on stray arguments
    return args


def fatal_box(text: str) -> None:
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_TITLE, text)
        root.destroy()
    except Exception:
        pass


def main() -> int:
    args = parse_args()
    setup_logging()
    enable_dpi_awareness()

    instance = SingleInstance()
    # A freshly elevated copy waits for the old copy to release the port.
    if not instance.acquire(retry_seconds=20.0 if args.elevated else 0.0):
        if args.background:
            return 0                                  # already running - stay silent
        if ask_running_instance_to_show():
            return 0                                  # the running copy shows its dashboard
        fatal_box(f"{APP_TITLE} could not start: local port {IPC_PORT} is used by another "
                  "program.\nClose that program (or restart the PC) and try again.")
        return 1

    try:
        App(args, instance).run()
    except Exception:
        log.exception("Fatal error")
        fatal_box(f"{APP_TITLE} stopped because of an unexpected error.\n"
                  f"Details were written to: {os.path.join(data_dir(), 'scheduler.log')}")
        return 1
    finally:
        instance.close()
    return 0


# --------------------------------------------------------------------------- #
# Embedded program icon (PNG, base64) - window icon, header logo, warning screen
# --------------------------------------------------------------------------- #
ICON_128_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAABTo0lEQVR42u29ebxlV1nn/X3W2vuMd751a67KPCcEMgAJIGEIkUFE"
    "GZUpiC04dIsgtkqr0N22dquICg0KMilKExptwMSQEAlDAiQQCCEkgSSVqkqNdz7z2Xut5/1j7b3PuTeV5N6qYuq3D59L3Zxz7jl7"
    "r/Ws5/k9v2cSfvweApjsXwfo8Ivj4+MTqalsN9btNKqXKNREuETQGBULPAbBFh+lhI8QAcUJeruqOEUTEW5WaHuRm71zuyPv9y4t"
    "LS0e4Xpsdh1+9fX8OCzmj9Omk2168ZicnNzhjblQ4Slq5HHG61kIkyJS9gg+2xWniiJ49Siy4tZFsm2T7IsURBSDYACDIqo90AVV"
    "voPIbQJfMN5/bWFhYc+qa82E68dDGH7UBWD4pAMwNTU15kQuVpFnG3gqqudgTNWL0FfFqeJRREUr6n0NT0WQMa/UgDreVPCUgAhF"
    "FFQgAfoYehjfRGiKp4nVjgotY0yKiAIiQiRQVlDvOsC3xZgbVfUaq3rL/Pz88iphyDXD/xOAdTxWLtyplEcXpq8QkRcIXG5EtnsR"
    "ElX6qhivriLoBp/KNvVmI44tOJlAGUOpqyOW8KFGsxNNpvqzM6oSnvECKeBUSBBaYljGMAe6XyL2Y/wBjM5LJH0RKyLEEoQJ1b2C"
    "XOdU/7kxOXct36P3cIL8/wTg4Te+UJ0j09NniuFlRs1LDZzpReiqkqr6Kuo34eRkn5pTNJVtpEyi1NUXN+VQHEIwBbritnVI9evQ"
    "QuiQgciNu1XFZALiBJpqmBPDbozeY2K/SyOdE2ucGFMSiFHEc5cT/V8KH23Ozd21ypS5/ycAj3Dix6amLseYXzNwBSLlvkIX72uq"
    "fof35jxNzFn02aSeWra1abaqfsiwFzenWmyurrLKumoRRECGnxHJcKIW7zUocYYPVIQGht1EfEsifyfWH5LIqBhTMWC87yFyrXrz"
    "zuX5Q9f9qGmEH7YAmCHAxNjUxsvF+DcLcrkKdFRB1W1VJ+dpah6nPXaoI0ZJNdt0CbdhRVD1KIrXsOfFhgkYMUQiGGOwCCLhB8Br"
    "EAyvilePy378wEJknwEGCeYi+w4ysFhCsQjLYrlbDF+n5O+SWJfE2LIIZRQP16XG/0nr0Px1R7r//z8JwApVWN+48XLj/ZutcLlD"
    "aHvvq6Cna9880SdyNimj3pGIkmTIPlfJqpptXFAjZRNRiUvUojK1uEQ1KlGJSpRNhLWCFYOR3ASEs54Li6qSqif1jsSldNOEbtqn"
    "mfRppz26aZ++S3GFQAyESDMNYVFKgGDYJ4ZbJdZbKPt9EknJiKkE03SdeP8ny/OFINgfltcgPyR1HzZ+cvJcY6K3RIaXeaDt8WX1"
    "egE9+xTtc6pPAOghuEI9E06pD7+XbcR4qcZEucZYucZIXKZsI6yxxXqGE6vFMdMM/Qf1rpnKD1ogF4pcwAoh856eS2kmPRb7bZa6"
    "bRq9Nl2fhqNswGbIIdfrEUoFWBLDrZT5PCW3xxqpGGNiBVX9aOr9H7YWFu5YvTb/NwrA8KkvjWzc8DvW87tGKDUVX/KqF2jfPkN7"
    "nKgOj6ebbWFQ70rqwymrRTFTlRE21MaYKNeoRjEWgye4gKqKyuA86ZDh14z4EQSV3E6EZZAhOx9ez1dICjNiMnHxqrSTPku9FrOd"
    "BnPdFu20j8muV0y4Zg9EQBVYFsNXpMRnpeQOaiw1izFoX5H/tjw7+0dA/wetDeQHaOs9QG1m5gqL/lkkck7PK6lXd54m9ll0Od0n"
    "eKCDIBJsqs82PhZhujLCppEJpiujVKIYEfBecflaZSddC9AHxhiMjTBxhLUWiSzWRogYxJohMBiMunce7xzepfh+ik9TnEvB62BP"
    "jCCY4FYagwK9JGG222B/a4GFTpO+KpEBKwZVxQlEGgRhQQz/RpnPStn1JLIjBpzqt/HuTcsLC9euXrMfdwGIMpAejcxM/0mEeQMq"
    "NJV0q/bt87QrF/oeoHSz0yUiqPekHipRzLb6JJtHJxgtVZDcpQv6ujiNqoqIwcYRtlwmrlaJyxVsKcZGMSYyYEx22IdZQFmhIXLB"
    "QRX1PghC4kj7PZJul6TdIe318GlafKdkeMBm2GKp12F/c5EDzQXaLiHKtIcGIIjNNMIeifknqeg3peTKhigKjOU7mnNzb87XLPv3"
    "x1YAIiAd3bDhNIEPWDFP6qj3RpWnas88x7UZRWlnNthIoGqdg3pcYtvoNNtGJqnEpUDhqqI5cAPUe4y1xNUKpVqdUq2GrZaxUYyI"
    "yVy3TDgy9T7sFjL0WQ+7QCLhfZl76L3ikz5Jp0e31aDfauF6/aAhTACFVsOGt9M++5oL7GnM0koSIguGoDFchg9EhJsp88+m5Bcl"
    "YlTEONUvqchrGrOz3/1+C4F8Hz9XAF/fNPkS4+N3W3SqoZqe4NPoxdrhbJ/QQTMxD2AscUolijhhdJptYxuoRTGp98FW5zbZe0QM"
    "caVMeXSM0ugocaUcUJgqqj6H9KjkN3gcbnNYaAqhEHya0m+36S4v011u4NM0gw1BI1gxdNOEPcvz7G7M0nEJJZODxUA61VEOSsxH"
    "TYVvEqd1YyNVP++9/+XWwsLHMnOg3w9cIN9Pe1+fmX5rLPIHzgsdvPsJ37MvdF1qeNpDPnrqPYKwfWSKk8c3UiuVcd4HTr9wszzG"
    "RpRHR6lOjBPXahhrUT+06XlU7weJbHPAB7h+n+5yg/b8Amm3WwiMQYgzjXDv4iH2NudQlMhk+AAoIxiUa6XKp0zFiTG2FEzC2xpz"
    "c2/9fuEC+X5s/vT09GjX8o6S2F/oOe9ideYl2pEnuT5dwg3b7NT3vTJdrnH61BY2VEfDxqtHjMELqPPYUonKxDj18UlspRQEwvsM"
    "B/wIEZoZ0aTO0Vlq0JyfJW11wATzYUSIxDDbXuaehQMsdNtENpgXpyAKI6LcLhX+Tmo6b8TXjdjU6/vL8Ia5ubnG8RYCOd6bPz4+"
    "PulK8bWxyMVNr8k2n8ZX+g4naZ/86g1C6j3WGE4e38hJ4zOIGJw6EBNUq/fYKKY2MU51egpbKoP6sPEPIXB/dB45MDTW4L2ju7hI"
    "Y3Ye3+0WZioSg1dl19Jhvrd4EI8nMpKxkUJNlFmx/K2p8z2iZMRK7JRbTJJcsbS0tHA8hUCO++aX42sjzMUNp8k52otf69qM4Ohk"
    "WRgC9L1nvFzlnOltTFVG6ftgN8UYvHpAqI2PU5/ZgK1UUe/A+x+4ej+WRdVMRo21+DSlOTdHe3Yu3IsYRJXYWOa7Le6cfZDFfpuS"
    "CaY+Raig9DF8yNa5lTgZtSZ2qsddCOzxPvmRmIubXtNLtRe/1jUpo3QzKAtC4j07Rqd47MwJ1OIyPZ8ixiDGoN4TV6tMbNvKyMwG"
    "jInwbgCqfqwe2eVqJrjlsVEqIzXSXkrS72Uaz1ONSmwbmSR1KfPdNsaEg5JkTOJFmtIQ7F1q06qYHd6ap1fj+OO9Xq8zBA5/aAKQ"
    "bf7OSV/211oxFzedps/STvQK18QhAeVLIHQ8wjnT2zhzckuWqaOItSETR4X6zAbGt20hLlfxLgR25Mdt44+AC9AgCFGpTHViHDGW"
    "pN3O1IQHMWwemaBkLbPdBj4LLPnMpDxOErqIuROTVo3Z4Q1Pr8YzH+/1lo5ZCOzxUft6rRVzcctr+lPajl7oO3QzkGcRUvXEEnHB"
    "phPYOjpJX12h8o0qJo6Z2LGV+vR05t+7H78T/yjaYJhwqoyOUKpXSdodvEsKbbChOsJ4qcahVhPnHVYMToKef6xPSRHzbWxaEbvD"
    "2+S4aAJ7TApuy5ZaLPJZa7i44TR9nutEP+s7tNCCw0+9pxZXuGjzSUxWR0i8C4EWa1FVomqVyZ07KdVqOOd+IOo+owlC3GCY8PlB"
    "AUXvseUy5YlxXK9P0u1irSX1ntFSlZnaKHPtBh2fEmdUcwqcT0pTMHcRpRVjdjh4+vTExEeazWZytHjuaAUgAvxIrfZea+Q5zVSS"
    "y7Udv0g7hX9vRQLYK1W5aPNJVOMyqXqsCGT2vjw6wuSOHZgoQp37gWyCy0zSSBxTL5WplmIiMaR4fOaqGWOKfIH8mowxx9cseI8x"
    "htrEBF49/WYbsQbnPRUbs2lknPlOi06aFEKQAI/FsaDGfFdsUrd2RydNt/c7nX/O9+QHIQARkNZnZt5asubXl50mT9J+/ErXopOd"
    "LytC33kmSzUu2nwypSjCqSImLK73nvL4GJPbtwdx0e8Pwh/eRM3cz8lSiUa/zzf27+fLux/gjv37Wei0mTCWUSM02h16SYJLEtI0"
    "xTkXyKaMqg7EjxlkEh8jNvAo1bExxBp6jWYWRfSUTMym+jgLnRZN1w+kUaa5zidlD5Hdg01qxlxgy1VJup0bjkYI5CgExo3MzLwo"
    "MnJVy2tyluvFv+aaAeRJMEaJKhNxjQu3nEQsNkTrjGAkbH5lYoyJrduK0Ozx3PDh353zOJfS7fepIPSc4113fItrOz1KJ53I9hN2"
    "oqrs3b2H9P77eWalzK+ccy4lgVaSFmHoYWGyWTQxjiJsZDHWHpELWDegiizt2XmW9+0HEwJcFiF1nq8fuI+FzE1MUWKUnkS8Q0bY"
    "a6KkKsSp9y9uzs9/nHXmFKxHAAyg5Y0bT6rArV2YmPF9fjNpSF09fTFEKIl6anGZJ2w+hdhEIXJnpHDzKiNjjO/YFtKxjzO1ba3F"
    "e0+SJPT7fdI0JUlTRuMS97Zb/NKtt3Hey17Cm/79r3HBYx5T5P4p8PXbb+ftf/lXfOtjH+NvL7qIE0eqNPopUSEEmtHOWbhZwRqD"
    "jSLiUkwcx9g4CiSWKqxTCFQVE0e05+ZZfnBf4ES8JxZDz/W5Zd99NNMekTU4VaoID4rl7WZE+8YQIYsYc9HSoUP353GY42kCsmSO"
    "F0u1+sDVCKeKd/6X05bZjKOXpVw79ZRNzMWbgs3PT741BlWIazUmd2zPqZLjR0FmnHq326XdbtPr9YIbqUKlFDObJLzoK1/ljf/z"
    "nfzRf/o9tm7ajCBBvatijGHrpk288PnPR7Zt5df/5r389NZtjMYRqfqC75fsu4wxBf+fupSk36ff65P0E9AQobTW5ukJa9deTinV"
    "61hr6DQawVyqpySW6doYB1pLAUcBXYEZ9Uzh5VZiXxJTU9Un9trtD6znYNv1qP7azNzbS1Ze1PSavsy1oou0Tytj+ALxZbhg00lM"
    "lmv0s4XLEyYkipneuSNLwvDHhYSUzL3q9/u02236/ZBCJsYixqIijFSqvOrzX+Cl/+W/8oZf+iX6/X4hNPkPgPeeNE15wgUX0K7X"
    "+cu/+ztedfppdFLN0sRkkJNW8P5BMIwYVMA5R7/bp9/t4dIUsZYoitZNIZZGR1FVes1WJgRK1cZMlKvsby6ikoFsDCeT0jZi7sSm"
    "VZGdUbU61u90rmGQaX3MJsACrr5x4zMjMdc11aeXul70C2mDzlAOfV+Vx0zvYOfYNP3M1dP8pKhncsdOyvU63h0fH99kNr7daZMk"
    "CcZYEBtCwBLC8+OVMlffdy/vqo9w0xe+QJqm2cmUh1XDzjmiKOKSn3gKv9po8rxTTmWx2w33o4oUkUdfJI7kkUj12b9ZDqEoxOUS"
    "tXqNuFQamI81uKnGWpb3Pkh7YR4xEc6lVGzEnuV5bp/dTWyDYIQUNcOfmzr3S5SWrUTO+ctb8/PXrwUPmLXIJBBb5V09lE0uNS92"
    "LfoMwFHfKyeNbmDH2DQ9l4YFNgZjQlCnNj1DZWQEd5w2X0ToJwmNVovEKcbGYGzAGjbgDYxQsRGf3Lufl//CLxwRKD4SiHzFla/h"
    "U/v2U4nyz81SyIxFrUUzgUNMlv0gGDvwOqy1iDUkvT6LcwssLyzinFuTOymEKOjoli1E9RFQxVhDz6fsGJvixLEN9J3HSubW4vh5"
    "7VDGG6+KFXkXEK8lambWAPx8fWbmLVhzuvfOvci1zJimJNmLqfdMluucMbWF1Gc3KAbNVFdUrjAyPYV3/pj9/Pzv250OzVbQP8Ya"
    "yDYn2GkpcgGbSY99keHxF164Zl8+f8/jL7yQ/dbQ6CeBuNJM25mg+k0WtcQYEBui+VmCwzCPYKzBWkuv22Nxdp5Wo5HJiylS0x9W"
    "DxiY3LYVY21mggyJd5wxtYWp8gh9r1iUDnCC9rlCe6btxVljTh+dnn5LZmvN0QqAAdzohg2nRWJ+t+W9v8R1zIWF3Q9cdSSG8zZs"
    "LxY+z5QRQnizPjWJseaYEX8eIm61WvT6KSaKMNZkPrkUabQ+t89i6HrFRZaJ8fF1C9n4xARpFNH1LotXZBlJuWHNtYIxiLFZvqEp"
    "NIIMZQ6pgI2C6Wk3mizOzZEmPeyjCaRTonKJka2bAljN7lNEOG96G7HYIsewjeEZvsfpmpi2994Ivzu6YcNpmQkwRyMAWTZV9Iep"
    "mHjSp/o835ee5ombkDrljMktjJWrpGi2CAEYgYZEjpE63h/L5geUnvRTGs02qYKNovAdebaQSEjONAaTAUCxJiOAZL1ft+JXMSZ8"
    "j7EBZ+QaLk8ll8zsWFOYBBWTub7ZdcngcFgb4RLH8tw8nUIbPIx5EvCpozo+Tm1yIghB5gaOVqqcPrWF1GvR5qCE5/naFQlRtBjV"
    "P3w0rGceEfht2nSZMfrinnfuJ13PbtSUvihGIHGejbVRto9tGPD7GSLULIBRqlQCzat61KdeEFqdDq1OSKgwWfQwT5DTXONYGWx8"
    "VscVNuAYgh0h3bdw+xBThK4DzjArXBIxOUsYMh80e84U78/KymwEYmktL7O8sICqHDE7Of9c9Up94yaiUimYIhES79g5Os3G6iiJ"
    "V0SgA5xNnydqz7Y8zoi8eHx6+rJMC9j1CEDQcqp/0MPoidrnyb5DOyuQQCEyltOntlDQOdkpDCsetISNonACj2L/jRFS52i0OkHl"
    "2wAqB4c0LLaRfCMGqjfffDL+4Wji+Cs3dnCiC1dQ8t+DNtDMTZTifQOvRMPbMio5qzoSQaKIXqfN8vws3vkV1UgrHt5jo4j6xg3g"
    "yb4vPE6f2kIJk0GGUDL/LO0wqg6PqBP9g4fqtkcWAAv4+qZNl4nYy7ym+izXs2VCkqZB6HnlxNENjJdr+IzjD5ue3Wl2g6lLVrjO"
    "a+fvodPt0Wx1cKrYDInn3T7E5IjcFLa3wAOF2g2bdvR0Q+7lmLB52WcPE0EiAwyQE0Or8QHZtQiDOAKS5zIaxMakvT6Ls4dJkvTI"
    "QFUEdSnV8QlKY6PB9TSGRD3j5Ro7x2ZInEckZBFtU8+T6duO9xpjL6sHLeCPpAXMw55+r3/QQznVpfo436WTlUM77xmJy5w4PkNa"
    "xO2DCs4EMUi3NfS7XfrtNhKZNW68kCQJy802nW4/LHhWvZOr++DvD9ytYH/zEx9Om5qsHvCYIniSEw5oBr5yQKe5qrcCNnMDczBY"
    "2HsKLYTkuCFbcSMFthCxEFlUPY3ZWZJ+P7x/9aZkirQ+swGxptAiqfOcODHDaFzB+VC63gMu8z2mcNoPpNHDagFzpNM/Pr3t6cbI"
    "Zc6rf4br2Fglq6YTvMIp4xspR1GGvLObydUyA3BkRVg+PEev2S5UqQwxcLm7BJAkCa1Wk2arjfOKzZB3mtXXWWuplEqU4ghjTOgO"
    "JbKSV8hUshn6rmNKGhCGTngOBgfXnAticR+52ckEJX8Nawa8ARmDSBDY8FGZucCzODeHS5Ls2nVIHAW8o1ytUhkbC+FkMXhRKibi"
    "pPEZ0sxVTRBmNOWJmtiu997CZfXp6acfSQsccYXUpm/qIpzs+3oOfToSJMtpSObcWpsg8a5Q15IJguafmNlINQb1yvLsHEuHDtFe"
    "Xqbf6ZL0A2/ey7j7RqNBq9UiSRzGRFhrMtspTFerTNSqdFPHA/Pz7G8sY6xh8+goI6VSKJnJAZmxwWUzUaF+j41yloJWLn5y925o"
    "o52AFyGKDLU4plouYY0lUR/C4Nk6FSceGXAWuQznnob3LM/O4pI0aJRV16MKI5NTENnQm0CEvjq2jIwzWariMkDYU+Epvs+4Ok1E"
    "sPCmh4vtr/D7x2ZmTgGelij6JN8zVe9phg/AKZwwOoOJDIn3gzo+GZRQFerZCKKmYASdc3QaTTRz1ZAhzsAGe6piwQTIWosiTBTx"
    "kbvu5p8OHGChXmNkchKXJnRu/xZnGsMvnnM2j9+2jflOO3zuCtVpjrlmYMWf5/dGQOWiischCtPVCs4r+5tNDi83QWBzvc6mWp3U"
    "eZa6nUAcGR9AnBoQH0zEUB2wEkycd46luVkmZ2YyIRgqePUeW61QGhmlt7QYDpoqsY04YWwm0MRAX2AjKRdpaj7rYx2Fp43NzJyy"
    "fPjwvQxlFK8WAK+YV6bGVDclSfpY7UVdyWy/KmOlCpvqY7isksfkrk2GgHMUKzlaH5JuySQ8L6YcRszhJAU1m6KMlUrsbbf5lZu/"
    "zOiTn8Tr/vC/8viLLmTjzAxJkrDrgT188up/4Vf/5m94xr3381+e+hO0hipxdMiFPHr2UVds/CDOH67ZqaNiSsTW8uFvfYtP7H2Q"
    "xvg45elpvHp699/HlmaLl590Es8+6SQanQ59L9gMzIpmOlNCmXoWawxCFQk+SVman2dyw4aVhls8ooba5CS95eXiEKbesak+xuhy"
    "mVbSC3gKeKL25Esap95GVU39K4G3DguAGRJ2t3379qoRXtFT9HHaM+PqSbNFTBW21aco27gAeoWKzVScZmAonBQzcAtFC3do0LMl"
    "+3dooxzKRLnE7maD5994Iy/54z/m2k99ihc+73ns2LyFso0YqVQ594zT+d3f+A2+cPPN3HXeufzyZz7DWK2eff6QK2bkGBhIHTIB"
    "K/3/lFC8upimPP/T/8InZjbxS+99L//0xS/yuZtu4nNfuomPf+GLPP/tf86fqXDlDTfQB2pxjMsypsyQtxTczHwnTEhNiyxJp0tz"
    "aXFAJGXn1HtPqVqhVKsGbZSB1NhGbBuZxvvgaibATk05TZ3peVVreMX27durGS8gwwJgAF1Kkqd7Y06p+FQv9F2Tv8urpx7HbKiO"
    "0E16mQs0cLFWaEkyGD7EjXtjyONWBbgmuEOe4DM7lNFSif2dHi/43Of4/b9+D2943S+RpilpmhSRtDzSliQJkxMTXPuJT3D/mWfw"
    "l7fcwnR9pMhBGEbax2QDCkHNPQKoRhFzScJzPvUvXP7bv81111zNi3/qp9gyM4NkG7xz61Ze+/Kf56YvfZEtV17JM6+/nv3tDqPl"
    "EqkQ2MJMG0rekkJCa0rJtsVGltZyk16rg13tGRihMjaepc6Hp1L1bK6PU7GlLA0/dDi7iJ7ximLMKUvd7tPzgONDQKCovriP6Anq"
    "/Hbv6GVvSDxsqk3i+440V4OrbGNBA+Yp0GYoJ4+V6jiYgwxkieAFqnHMUprygn/7LL/97vfwi694JUmSEEURURSvyO8zxhDHcYgu"
    "Ah/+67/hwwcP8GBzmXIcZ2YmmJtj2/0A2orTn+GdarnE6z9zPa/8vd/n9970JpxLi+SSFf2GUoexhnf+9//Ob77zXfzs525gvp9Q"
    "i+LM9GdA0uQgMFeoA81qjaGxMB8KZGRw4tQr5ZEaNo5DTWwWfKvFZTbVx0h9lpspwtmaMInzaUAfL17tBQjgxsfHJxC5IlWV813P"
    "Vgin00vozjFTHqHd7RDH8VCuOytBX6HSV3LbkrlTebRNTN5+JXDn1hjERrzwuut47R/9Mb/ymteQJOngux4hBSxNU0496STOv/xy"
    "Pn3395io1nAa+Hh/PBJNxQBBmLwIk7UR/umuu+idcw6//1u/WeQi5HkGwz9RFFB8v9/n9Ve+mtf/6Z/ys9dfjxpDNGQqc1wxnBE/"
    "HGvwztOYX1ypzbxi4hJxrVYU0EiWULJ5ZLyIYKbAlCpn+77tKSKqV4yPj0/kZsAUWqBSeRyYzWV1/gxNJBUNrp9Txip1IhU6ST80"
    "X8qjXEMkRYHqNefAzZCVsYOOAZnpyCsFPZ7pWo3X3fBZHv+61/Hbv/7rJElCHK89k0ZVufQpT+ars7MYYwNRYxn42+vBAbrqFyNg"
    "JahswsZ94r77ufLfvTYrBJVHzTGI45gkSXjzr/4aT/qVX+EXb7iByXotw0VmxSHK4w8FwZYlonbbbbrNVkGM5cJSqteLNkeSFeGM"
    "l2uMx9WCF1DgPFIRFY8xm4mixxWMey4AqvLsvghbvPObNaWfWSOvsKk2RrvTCVJu5GGI8wHKyzttDYdQhYEt1UxoHMrGkTHe8fVv"
    "cPj8x/I3b387Lk3XlUaVb8DmjZtp+ASHho0vQOqxKgBT2H9rLYudDodtxBMvvnhA9KzhGqMoIk1T3vOnf8rixRfw9q99jU31Ok4H"
    "eRKyonWNGdQXAsYK7YVFfOoYIl+Iq1XERIXJ0ixEP1MbJQQKhR5wsjqmvPNpuJ5nDwuAC7/oM/soZ/m+1DMAEZoYCJNxnWa7RRzZ"
    "IdS/slNG8T9jVnTXKrSFDAkGBq8wVi5z26FD/HVjkX/48IcGbOE6VbeqstRYppyp4txDGQ4ZH1UwyDCI8BkhspZumiKVCkGLrr2i"
    "qBAWVf7xAx/ifa0mtxw8yFilXAS3dEUeAVlijRQmNE1TOotL4b405DFGcUwUl1ZoIy+woTqa1RKEHorjOE4ilV5YsGfmvE/W0GHH"
    "Zg9nWFVO1cS4zC/NfX+L0O73iKOoaLmiKkMt1QY4UFdEyiiQv6x4PiyqtYZf/8pXeOufv50TduwgTdN1V+DkN/6Nr32Ns8anis0y"
    "No/IHasKsIVr6Q2UyyVcEpJQjyZ72TnPjm3b+C9//g7e8NVbMTbKDogZHJIBwkYZRFittXQaTVyvF7SpKmJN1jRDi1iMz0rMalHw"
    "BhDBopyliVGvqHDG9PT0ZsAbgJ7tXeysrY1557aqkySDJt7DZGWEtJ8UXTsYBv2wMjSa9d4TkSzvf3Dqi1YvBE5hplbjXbfdzqZn"
    "Xc5rXvZzpOtU/cOb32q3+fw11/C8s86gkfQRscHtFLP+zjq6inotTInBeWW8Vmesn/Dtb9+Jqi88kTWnYUcBuL7qJS9h809ewTtv"
    "+zoz9TpOFaPDJnPYLGQAz4Sag9ZSo4g+ighRqTTgZrJbiKxlqlQPxccCKcJOSaSi6hBTc3Bx4QZGIk9NVdisqU6ow+ng1I6Xq7R6"
    "nUGYR4YKOoaSQFYELQrRGgRNYCAA1ShiT7PBhxcX+PM//bMiN3+9D+cc1lre/Ptv5fwk5YJtW2klvshL5FhDAQXGMFls32Ajy09u"
    "38KHP/yhQF8fRbJLnvzx53/6P/j7pUV2NxqUo6jogJabgJVcS2Y8raHXbJJ2e5lJgbhcHhLewQ1PVOvFfybARu/ZIKkm4cmn5gJg"
    "POaCFNiqqZTVZxk9oYNFLSrT7vVChK3w9YfdvSGqdAVBNCieYMgddMBktco7b/8Wz7zy1Zxxysm4rFByPY9cY/zh2/+Uz7//vfzZ"
    "Fc9isdvLeu6YAcO2XhmQVfmBQ9lF1lgWO11efeHF3Hv9Z/n4pz5ZIPx1aQFrcc5xxkkn86zX/AJ/cfvtTFWrgcQSQle03JxmLuGw"
    "aRWFzvJy8CKyiqI89cxkuMerMhZXs6Kc0JepimebekkDvrsAMGZ6+ow66Ominu2aFrvgnVKPyhgV+mkSqFrhoZJWZOmYAT+wIp4+"
    "sBJeDRUbcd/SIjfg+J03/kaR7Hg0m/+7b30r//DW/8w1L30J1Sgm0SGSya4h53ktCSFmQNWKERyGOIp49xXP5N9f+Rquvu564jgm"
    "TdN1C4Gq8h9/4w3cCNy7tETFxvicF2DgSRVmINcF1tJrt3D9JGtDEyHWrrBeXpVKVKJqy4P6RoRtOONVEeT06enpuulGiztVmYhR"
    "NqsTVzRkhpFyFU1TvHcD1S8rkxRkOAtgyM7L0Csig754E9UyH7jrbp70sy9kx9Zt+HWe/nzz/8df/iWffPvb+eJrrmSiVKWdOiI7"
    "yMAp0tPl2GoQgwDkmUFCZITlXsKFW7by0Wdezute+LN88CMfKdy8dWU5O8eOLVt58gtfxPvvupOJaiVz3VYC6WGknVtT7zy9ZhMh"
    "sIW5QFF4iEpsLaPlCi5LF1Ngq0/FKHhhwnu/08RqT/HGVGve64T6FS0pR0pl+kPqTbMoYA5Khji/IRdPVqGBXFiUkjHMdbt8ptHg"
    "9b/4SwWIW7vN90RRxNXXfYb/+Zb/xNU/9/NYhWaShBwCiuSbPJvjmPMBMp52RXpZbA0LnR6Xbt/ONT/7M7zlV36Zz9/0JaIoWh8o"
    "zDDE6//da/lss8lsp0Nks4E2cmS7lJ9layzdVgtNXVEXwSqTLAL1uFw8nQpMo1Tw6sVU1ZhTjIpe5IAxvB/JmiTkElePynSSfnGS"
    "09Q9ZH1C/r9m1X4Z0WNWSq5mffDGyhU+s+t+Nj/h8Vz4mPPwuvbT771HBA4cPMivvvYX+dtnXc6mkSqtNCWyQ/kFRaKGFLl4Ry0E"
    "QkhqyWxJjgnUBGLnULvFmRtmeOdTnsIvXHklC4tLD5/d+zCJr6qeC849j81PvJTP7Lqf8XI1K+tdSasPnpKCKPJJQq/bLrKshqnk"
    "4CXBSFQpPsOrMKaOsdC5CoWLjELdE14oqQ9fHsqLKNuIpJ8O5uU4P9xdfVX69tA664AqLvSCBhr1mv37+ZmXvjTTKGtXzbmn8Ku/"
    "8UZePDHJM047mdl2h8hGgx7/ZmCCcv/9WKuQTREIMoNQc/ZaKYo52GzyM+eew+UIb/jt3wrFsN6v2QzksvIzL3khVx84QFSYLF0R"
    "UwnRVFYWp4ih225mNLJdUYocQsRKNY6LuIAHqijj+LxNbd2IcKlHGVMvMXlmq1IyNrROcQOjkLr0oeVM8ihVNtnrJWvY22iyq1bn"
    "eVc8qwBC63H3PvO5z3HfZ/6VP3j6ZRxablCyUcGg5fy5ZqfDiKyirY/aD8zCwGZAypgBTVuKLIcaTf7wisu59eP/m5tvvRVj7JpN"
    "QX5yn/usK9hdq7G3kd3XEbOZ5CHrm7Q7uDTFRPERYGzw5PIWM15CweA4TkJOJZcalEiDCQgDEzP+P7JRyDPPc/8Q0iTFOV9w/DIU"
    "Bs5NpRYMYNF+Ca9QLcd8/eABZs45mx2btwQ8sQ4aFeC///Ef8x/OfQxla3EqA1tZhFBDiboMZSrpKixyNGagiLQNhbwHttbgvTJe"
    "rvC6M07nj/74j9dlcfKStx2bt7Dh3HP42sEDjJRKYTyBaDHVBPJMomBi84PoU0fS64QCnCE8lquJkjVExhZNLUw2Si/geYmMohZg"
    "JGvxUvyh2BXlzKHlils385VLYsVYvjI7x4WXXhJO9RrVZO4lfPErX6H5zW/ys+edy1ynndXVDbFleZDJmNVpfMfWymcoODMc3jZG"
    "imRYYw1znQ4vP/989n7pS9x2xx1Ft5K13iPAhZc+ia/MzlG29uELWuShyiFpdwcgUFauu4ghLpJLw8aPaNaI26s1II8BpYo3xYwd"
    "IM46ceeDVpFgAvpp/yEnV4d81eHAxvAi9r3nnl6Xxz/hiSvyBte6OH/7wQ/wvC1bGCmXiijXcB5KsUmrkJDh6GHAcLBLV8U6FC2e"
    "C3MEPJO1OpdPT/P+D34wA11+XRruCY9/PPf0unRTx3DRoKxIvXqoGeh3ewOJ19V5/0JkbLFmAHX1JhwWeYxBsKJCedVCRWbAo+sQ"
    "fdnvJ9kF65pPf2QsC50uc7UK555xZsYfPTr6V1WiKGK52eSbN36e559xBs2MlXwk25g/4shigG6eMLpGsAnQ7fYw6sNByEvDZWhu"
    "tazkOESEZr/Hz5x5Bjdffz2dXo/Irq0uMheAc848i4VanYVOJ6z/GoUnTfqoS1fkaAxlNYbWfEOHpQJZ3oZakwuazSU6jz+LLaZ0"
    "DLs2vWIxB0disB9+qDRkQF6UrOXAcgM7Nc2OrVvXvBn56b/51lsZW1rilJkZOmmadR8Z5uoZ2PsM/KXeM1KtMSmGu797z9q7c2Tv"
    "u+uee5g0lnq1FipwV5GEkq2XFs1xhG4/4exNWygfnuXWb35jhUCtRQB2btmMnZ7iYLNFKWf2hsMpQ+0ecvc78Osel2TrkpN1Q8Ur"
    "VuxQ6jnZCJsgBCZrgBWQ4IovXOVQZs91ut11BUBUoWQs+7odxrdsoRRFmU8vaz6NN918M2eNjFKJohDeXJvVBoGf2Lmdq666atC9"
    "a40Rxo9fdRVP3b5j7SXmEoZX1colTq9WuOnLX1khxI/qDnpPHEWMbd7Mvk4nIPe1rHMWD3BpmgHfI4PYYa1gGLCjJn/RHnGk6sqE"
    "KmMMvX6viA0UH/MIF5pPxjjQaTO9ZUvBKK7HNt5z53c4f8M0GYf9KMZHC5Jlqd3h1Zdcyjf+9VpuvOkm4iii3+8/7ML2+32iKOLz"
    "N93Ebf/6GV516RNZbLWCCh3iN2WIBh900RlMIT1vaoq7vn37uhJGcuGc3rKFA51W0RjyUV2K7Kt9moQTvXoljnCrRgd0sck3KS1S"
    "uvNmVTpI/x62N2lKt9vNWrOtLaRiRVjqdKmPjbEeTJb7yAf37+PE8QmS1K2h2EcKm506x0S1yn9/1uW86uUv595duyhlzZryLqDO"
    "OdI0Rb1SKpW49/5dvPLlr+B/XPEspsq14AavEmjVI0cXJCvWPHlygoN7961LAHKhHBkbY7HTHQjdGrVt3l39SIuzWuD9kBkx+Y4n"
    "q3raaVb6pUf4sFartUL1rVS/ujJalP13Tx1jmQCsNRgnIiTO4VotJmrV4DoWI8NWJnDkXr/qYOCvFcNCs8kLHnMebzn/fJ5x2WV8"
    "5GNXYYwhisIcQZu1chMj/N3HPsYzLruM3zv/fF5w3rnMtZtEsroRtxbt7YdEolh65z0T1Srt5eYKIV7rY3RslP5QMudazJ2sEBRd"
    "+aqu1LiDidXhbyNVHCK2t0qVJYTeOHIE+9hsNoMdN/JQu6vD6jGMaFVR+t5TLpXWxR0IQpIm4BzVbJDUENk7eOcKIKoFQFIJ3szs"
    "4jK/dMklnLFxI7/3W7/FX//VX/CEyy5j6+YtgGHf/gf58o2fQ/bs4UNXXMFTTzmFw8vL2KxbpzCYPl7crh8StqG19+qpRCXUpaTO"
    "hTjFOh6lUpl+cZ9HMInZZuoqry83xcUs5KGJ6S5vGpq9OdGiYspFBr1dxTyui/FmyIQkzhUDkofF0RhDt9ul0+kwMjqSXU821o3B"
    "XL9hE6CaAY+j6aGb++F+4JNKzpIVYpIjlsFpDMrJgw9+8OzyMpeeeCKf/eVf4sa77ubGGz/PbcvLAJwwNs7vn3Iqlz33ueA9s8vL"
    "wQbng6nyG/HF6g7dHIXm0ez6NBt7MzxYes1RTw3p+Eey37lpW7m4D4+DQ7/Y0L53qKaEroTqM7zcHoE4gJaYIReQoqefsSGRcbiq"
    "R1VpNBqMjY3hcEObK5lF0KAiZaCeS8awtA5/PP++UhxDFNPq9kLzZp8vTuiAJvl+DEm8rJom5jUMqFputxEjPO2M03nmuecOEUZK"
    "2ktotNpkffbAKzI8wTdzl4wMBn0ME2f5W4wRWv0eUoqLLmDrCXl3u13GC45keObx6pCwPmTPdejAFepePYlzmbYILzQl66QhzkUa"
    "prrQKGi1UGvW92nGCMakrjtorJxF5ZaXl9m0aVMIvw7DgVVkVK6yy9ayvLS0rtPvVTFiqIyOMNduYs0W1Lkh2zfEVA0bBZ/pBaMF"
    "Y6g+68GjsNjqoNoeil4O+vcMl3/npkaLU+2KjdaCT/crJpJGIsw3W4xNjq+gstdKOi8tLTJjj9Tldci2Z6bn4RNdBjmbLvUk3q0w"
    "062CtZXUiJqbrAhLYjVlkOGTeEeinlIUDcbzsdIMtJrNYjhysQ/F/w9YpdQrU9UKraXF9SHjzN5t3rmTexfmKWU2eYWoFw0CgyoQ"
    "zacRMVDHOrDj+IBLrIRehzZnyjR0Ayff/OzvNBtVV9yjX90JPHuv19AYUyz3LCywdecJayaChtnr1tIiU7UKqdMBja2DX3TV6RqY"
    "nSHjp4N97HuH865INHMIyxg1IojqTUbxLQMsYegNpU84VXouoRTFR3RFVJX5hYVHkEAtbFbiPVsrFWYz12ityDhfvLPPO49vzM2H"
    "bpxD42G10AB5K/dCcsBnMwYL4ciey/7Nf9SFH7LNL15bveFFgwYdvLaCXcyf99yxuMi55z/2qFzeQw/uZ2ulRjI8DXWVkKxwD/Wh"
    "1WyFphbougQ3NGi7DyyJzXCGtIxYudUqLBlrWlknEJUQwu0kPSqlclHKNfzh1lqWl5fp9bshEWNFj/whsAYk3rGlVqdx+BDNbnfN"
    "WTP5ojz5kku4u9ul2e8Gt0yzTc4WfLAAvkgyUXXFfxdVu9nfyAoB8QMtkZ/6oYbPuZo3MtAQmgmcqA/aIhO+SAxL3Q73pSlPfuIT"
    "ChC7Vvax1e3SOnSIrdUqSRZ1HUBdX+ArchCsnuE0zcId1IEubie9IoxsUDoCSxJWViy3msS5e413naaIzIsNMYHsQxv9LuVSqSj0"
    "WP1I05S5+fmiX3/hiuhKgew7z6b6CHZujvt3714XR66qXPiYx+C3bOKb+/ZRjyKcH7Z+eQfvzBz4cJql0ASu2LjCbAyhNilsqg6u"
    "3YfND6fdZWZAi2nkuVDkY6cURV3oofC1B/cR79zBeWeeueZ6h3wtdu3eg5mbZ2akTt+5hyB+HepMfkTOfdVn9ro9mml/iAJWljA0"
    "1Yqo7yTi7zWViYndRmQxxXJIIo104GM2el2iyBJZe0TAYa1lfnaOpN/P6tV0yDcf+J7OK2OVMhuThNvvuGNdAuAz/uAnnv1cPnH3"
    "3dRLUXYydcgc+MI+ah6GzQM4km2U12DLXf5veI86X7h43uUbH7SBwaFkfX28x2eapHADcm/AB5NZLVk+cfddPON5P4U1a88HyNfi"
    "G3d8i039PhPlUki8yQ/6CoZugLd0yPTI0MvWWDrdLr00oZ30Cu4/UmEOq53QtHKxkm7cbebuvruFco+KsMfExa5ZgXa/G+bcl8pH"
    "7PebD2uYm5sdaIFhgFaMWvFYMZxTrfLlm7+8TnAUbu0XXv0qPre8zMFGm7IxqNOB3VYF70BdKIXKNky9z0Ciz17zSPb8ih/nwqxC"
    "ddnnDDDAQBuAFPY/GySVmQOvnrI1PLi4xE39Hle+4pVFfsJ6BOArX/4K59Srg6aTD8EYQ9yD5teziqfUIIyLzQZOoNXvhJHFWZfX"
    "vWJ96Jvg75mbu7tlAC+Gr0ci7BOr/WzcuRih51NaSZd6pVIEYo6kBWZnZ0n7fSwyFDnUggkUhE6a8MSZjdz+5ZsLDLFWcOSd5+zT"
    "TuP0ZzyDv73tVqZyWtgPncgCD7hBl47shGsOArPjKjr4CR5CJiA66DmuK8zAoD2NqAsnzucIXPHOM1Wt8Ndfu43HPfvZnLxzRzYb"
    "YG3eTp7T/82bb+YJGzbQTRxmyJQW2ibXruLRzNMZwIJw0CJjWG63cElKgqfrU/IcKQfsE6s2NP76OnkFH+iNsSr7TSSLGQ7IrdxC"
    "r81IpfawVdbGGHq9HocPHQrNGXQImefsIUq73+cxGzbQvue7fPu73y3U+1rzslSV33vLW/i7PXvY11jK0qayDRhSzZIDu0xAcuEo"
    "VH82nt4X4E8LN2/YTJCDu+wngERX2GFP9vnOU4ks9y8sctXBQ/zeb//Oupi/PDR+x3fvof3dezh/ZiPtJBkA5UIQMoFUjkAI6SCI"
    "h3J4dpZauUqj3w3KLKsObophn0QSoSD2xiJjqhdFt1jv20sS2b0SaZxZfCMw32lQKsXENsqrBo6YtXN49jDdTivMz8m7bA6ZhMR5"
    "pmsVzlXPP33y02uOlRdawHsec9ZZ/ORrX8tvXXcDG0bqOO+GNskPVKZPEfWFYvCFUGTI3uvKvys0hQc3eD6EaF2GwAdcwLBmSL1n"
    "qlbnjdddx8/+6i9z2sknr6vaKfda/vlTn+Zcr0xXqyTeDbh8CfpeVYsWw7LCzA5iJ9ZGLC03aHXa1KsVFroNTDY+p6TKQazOibXW"
    "+3bPlW/JBcB09uw5YETvVmO415S8yTpSGiMs9Tqk6hmt1jIcIEe008459u/fh4gOTh86ZBKgmyY8f/s2rv7fV5Fmqd6sw0/23vNH"
    "b30b35qe4r233srmej2EazNbXbh8eTRT0yAMXkPM4kgb74ewRBHgyckfl9nZYaEJLqTxwbvZMlrnHV++mb0nnsh//p3fWXePA2MN"
    "qXNc/fGr+Olt2+gmyUqPS3UV8NOg/jOByN3bULiTcmDuMNVyBWdhqRemkYsqFrhfYt8zBove3Znbc4CsQ4glFI1cX8LwHVvS0Bg6"
    "70vvme01Qx8+9UeMxedaYGFxgcWFhdAm3meSSziJorDc6/PkbTtxd97JdTfeGOzSGrOMc5Vaq1b5yD98hLfe+R1u3ruH6UqFxKVB"
    "Bea4IPMS/LCXoA5VFzCC9yuEwBe+fXAbAxHkMnOSmY8hE4FCzzlmqmX+7f5dvP3++/nHv/87SrnLvEb1n9/7dZ+/EXfnd3jSju0s"
    "Jf2wxD5cu6gOoIkO1P2A+QvSYo3h0Nws7W6H8foIy0mPnveZ/RdSEe4UowbBi1yfAaJihhuJN9fEePaZ2OwzMaXcrggcbC1RrVUf"
    "MclRM95+394HSfPEUT+IBZAdsrJVXrxxI+959/9c12LlWiBNU84/+xze9fd/x0s/cz3fXVhgqlohcUlYi9y9y1m9LB6eY4NA9bqh"
    "nzT7GYDEwBZSMIxefeF6ikLfOTbWytxx+DCv+LfP8b5/+AdOP+XUooBlvZnH7373e3jJxo2Ujazwtgr6ehgLrEpGUVUiE9FstZhb"
    "WMBaS71aYbbTKAJEkShzWB6QkolFEafX5BBk0DO2Et0m3h/oizXfNrHmM4GsERY7TRL1jNUyu/sIG9Trdtm3Z0/hFg78wmBvFjo9"
    "Xnbaqdz/2Rv42rduL8zHWh95Fe4Lnv1s/uhv38dzPvkpbtu3n80j9RDA0tz1H6jsgssfZvJUV7itqkOCo8MnXjPXMnxW4hO2jtT5"
    "wp49/NTV/8pffuTvueIZzyBNk3Vtfo4Tvnb77ey6/npectopLHS6oXev5lHNAczXoXXMqXB8iBekLmX/gQOhFKxUBmuY7zSITAhV"
    "lRTuNlYbJjKR8wdI09vyy8iv2PaWljrl0bHzRKLzO4q72HeMZFRm34Ukh5naGAvLy49o46wxtJoNyuUyI6OjgUWTQcV7irKhWqW1"
    "tMg/3HsfP/fiF4dI3XrspjEkScIF55/PyY89nyv/8i+YSFKeesIJdF2PJBupxtCJ0VWnacClD0yGFmziQAhMpn8T7ykZmKmN8O5b"
    "b+E377iT933sf/GC5zwnK1mP1xfpzO75V/7Df+Dy+XmetnUby/1+yC3wOhRP8cU8QjIXV4au31rL3v0P0my1EZSZ8UmWtM/+1lKR"
    "Wm4EPm3q7mBkJRb5xPL8/Edz079i1a23V8V42WMj84CUKGVrYQw82JinUipRLeecwMOHgUxk2bv7Abqtdsj/z+yZqmIVZjttXnv2"
    "2dx/9dVc/4UvYNdbVg2hKUOS8oLnPpdrb/w8f9Vu88r/8yk6iWNjrYqqI83QtKgWJ3hAEPlgLh4mECTZc6kLWGBzrUojSXjZP/8T"
    "f6tw/Re/wHMuv5wkTdbd2yg3Fdd/6Qvce/XVvPass5jtdEIjfz/U8E2HEk1yZJibNVWssczNzzG/uBimkhlDrVZjX3O+KDItAQcl"
    "4nsSmYqKqPirVhymAdOA1GN/g/Hu3sRYucWWvc0wZyRCI+ky12szPTaeuW/yCFk8Buc99993L965bHCHL/CDc56yEX7zxJP4rTe+"
    "qWixst6MoSgO5uC8s8/m1ptvZvIlL+HZ1/wrf/6Vr4AKG2s1SlbwWUjUu4wNzIUiJ4TykG7G6qWa4tRRtpaN9Rqpd/zJTTfx3Guv"
    "Y8erXs2tX/wiZ552Gs454nWe/NxLSZKEN//Gm/jNk06iYsJ6sYpFzc2Z8UOuX6Y9ImNotZrsO3CQyEakzjFeH6Hheyz2OiGdDYhQ"
    "bpPYN40R4/XeRly5gaHh0sNGK1peXu7H9ZGpyNrL5lTcRb5rqig+rwryCSdMbGSx2Qhdwx4BwOV4oNfrM7VhQ1HEIBIoyVbiuHjL"
    "Jq792q3cqZ7LL7tszZM1V3+Pc444jnnOsy7nCc96Jv94512854Yb2H3wIJuqVbaPjTNWjilZUwR0clIlP2FWoGQM9VLMeCnGinDX"
    "ocO88+tf47/e+R2Six/PX7z3vbz6ZS8rSJr1Ar789EdRxFv+23+j8+lP8wePexyH2+1BTgI+9FLJTRG6MkKZge1+v88De3aH7mIm"
    "FKhundrA/c1ZOllDbwP0xfBxW3MdW7KC/6v+gQPXE8YE+NUJ1gbwYzt2nCIJ32riKy9Nl7giaUoTIQISrzxx66n0W132z88RP8pI"
    "uHwG0Jat29h+4okBqUs+2BlK1tJR5VlfupkPXXctP3HJJUeFpPOT5b0v/vZrt9/OBz70Yb587TVMLCzy2PFxLp7ZyKkzG5gpV6hX"
    "srp5DE49zV6PQ70O9x6c46uzh/nm0iLLU9M86TnP4Rde/WrOP/vsYgPNUTSzzKOnURTxhS/fxKsv/0n+9dJLqGb5EibP3lU3AKUZ"
    "e4lkCSepyxhUx327dtHtdkO/ZOcYr9YYmRznlgP3EWVDN+rAraasfx2NUhXponre6oERq+/CAm5s0/Z/Sa08Z0Padf+xP2dNkdih"
    "bKqP85ipHdy9Z9ejD6YdEoKdJ57Ipm3bSNI0jHQRIRVlQ6XKZ/bu5XebTW756leZmpgIUn6U8358hvhzQWi0Wnzhpi9x4xe+wLe+"
    "8Q0W9+4jbjWRfo+kHyYgl0tlfKlMMlJncvt2znvchTz1J57EUy+5lFq1usJnPxrhHKZ8F5YWufjii/nDkVGu2LGduXanyHUUn7mh"
    "bshr0ZDXq84X/MD9D+yi2W4XGcdpknLS1m3c255lX3MxZE6hlBD+yo6675SqtuL81cuHDz2XVQOljygA9U3bnh5bPtvw6l+VLJqn"
    "ph1a2YupV56w9TTSdo99c4cfVQsMq76dJ5/Eps1b6aVpMWotVWXL6Ahvu/VWvnz2uXzhX6/BOR/GwB1Dt+88rGtXAbR2t8vc4iKz"
    "8/P0eyFWXi6X2DA9xYaJSSp5z738ulNXjIs7pmvJhPIpP3kFT7jj27ztwovY12oQY7JEV1/kNfgiyumCJ+B84bE88MADLDcaAXhm"
    "VPR4rc7I5Bi37r8Pa0IzrirK3VLmHdGoL1ljDPKMpYMHb3g0ARiYgi3b/y0Rc9mWtOve3J+zZKnOqXqmyyNcsPEkvrfnAVJ1a27B"
    "4J3jhFNOYWbzZnpJmo1iDTV7m0ZHePm/fY7qi17ER9/3vmNStUcyDXlyxqNtpPe+OK3H6/tzu/9zv/jv6H7843z4sqdwsJmf/OB5"
    "ZIPpBjGJDKT6vEDHKw/s3s1yY3mFFvLec8rWHXx7eR+z7QaxCdlcFeBd8aj7VlSzNe8+t3j48NOGVf/wiT+SAGhUH32gJHLlIWOY"
    "1kRO9wldIDaGRr/HWLXKZHWEheXlNatFMYaFuTniKGZ0YgKXZb2IMbSThJeeehrv+z+f5Oa5OX762c8uNuJYNiHfyHwziyCLriSE"
    "hkHl6pF2x3LyfUaTv/6Nb+S+D36Qf3z601lst1cUtgh+KIE1z0jOWEsRnPfseuABGs1G4XKKCC51bJyYpBvBvfOHKFnJGkIK37Ex"
    "n7I1yiLixL0maXV25Xv7aAKggElajfvj0bHLLObE/WL9xa5rSkN1A4vdNidPb6Lb69NP+2tu9miMYX5uDkEYnxzPCktCDUHiHD93"
    "6sn81ceu4ksHD/Ezz31uaDDp9Zg3Y1ggHunneD1y4bXG8Npf//fc8Tfv5X8//Wm0+z2czyOlviB1NGRykDcKVO+xNoTad+3aRafT"
    "IRo2t6rEccTGDRv41uyeELjKrt+I8JGo7majsomd3tg8PPu2I53+YR7giEnq3tu3RQY5IDE32hrVrOWoEaGd9Llv8RDbN8ysqMZZ"
    "K5374O4H2H3vvURGEAnEi3OOXj/ln575TB744Af46Ve8HJf6Igbw4/IIU0QM3jte8MpXsOv9H+Sfn/F0kiQldR5baB1fMH/DOYfq"
    "PZG1NJtN7r3vvgLtDzp+hsLXLdMz7GnO00p6WCOkGGoot9iYu6REVUWclbc9grl/WAFwgG0dfOBzzvurqkbs9VHd7bYR+QzhODLs"
    "WpqlI57NExtIhmfarJHJO3TgAN+780580g+NnTTUI3R7Pf73059G9V+v5dJnPpMHH9wXmjCm7qgnkf8gHnnVcRzH7N23j0ue8Uxq"
    "11zLx5/xdLq9hL7zWeg123yliEQWuX+iWCscPnyY++67D5emqzY/FMxOj42jkeH+pcOZ6hci9SyL4Wqpu9hE1qu7qnXw4OdWA7+1"
    "CECRcCKGt4iSNE0kn7ajGg3NCUCUOw7tZnJinNFyNdCm61isOI5ZWlrk7jvuoLk0T2RDqVfqHAutNu978pN57p4HePKll3DVpz4Z"
    "6M6sRP1H7ZGmaTEZ5OOf/jRPufRSnrN7D3/z5Ccx32rjvMMSEL7gsjCvZpFKxTuHtaF97AO7HmDv3r3FsOlhoffqKcURG6am+Pbc"
    "3uJce6AqcK3U9EEbSaQuwfu3PLRi4KFu3yMJgO03GrOmPmqr1jxttzF+o3pzik/oIsQitFxC6h0nb9jM/NLSuid0WGtxScL84VlU"
    "HaMT4yG1zCvNXo9n7tjGuRh+96/fwy2793LZU55ErVYr0L0x5oe68c4F22utZXFpide98Y38wx/8Pn954sm89OSTONhqhaqcFVVK"
    "DHILshR2G4dyu1333U+j0ThifCEv2Dl5y3bua85yoLVMyYY5yjWUe0yZj0Z1XzbWeuW/NmcPfyIP+hyNABRaIj3z9C/Gy42XGszM"
    "fcb6C3xPaupJBUpimOu2majW2FAfY66xtO6SaJO1YFtaWKC1vEy9PkKlWgFgqdfj1LFRfn7nTm78txv4z3//EWrT0zzuvPOKLKG8"
    "ePV4gri1uHbDruIHP/pRfvGVr2THbbfx/idcwo56ldlOl7ioqfRFIUlRWOJD9xTnEvbt28eDe/bis37IR8zAdinbZjbSEcddc/so"
    "2yxkj+DE8L6o7hdtyUbq72kePvRzj3b61ywA7N+fxmOjd8ViXrWEdfNizMW+Q5oPMTDCodYyOyZnKJmI5VZz3UIQtEFEr9NhbvYw"
    "3jtqoyNUSmWavT7qlReedCJnJSnv+vCHef911zG2YYZzzji92IThiOLxFobhoZXDbuInrr6a17/+dXzzfe/jrZu38Pozz6TZ69JN"
    "XMbv+yy274sM4lBFFNiT+YU5Hti1i+XF5WL03BE3P03YMD5BfWSErx3aRa74FKgjfCIa4RZbcXUR49CXJa3W9x4O+a9XABSwSaNx"
    "bzw6NlEx5tJd2LSGmrNdn25WTuZRZtsNTpvZRpImoc2aXb96Dn+jLC8ssrywgIks9foIYixL3S4njI7ycyedQP3Bffz1hz/EB665"
    "mr6xnHzCCdRrtUITOOcKAuhotEO+4flAyHzDjTHMLy3y4Y9dxRvf8Ovc/O738Bpj+f3zH8PmaoW5Tmeo2sgVM4J1iIyKgObyMrt3"
    "7+bQoYOoPpSxHKh9IfUpo9Uam2ZmuPXg/aQueBmpCCOB7+cqW0trNorw/h3Nw4fe/UjA7yHu3toSszG8GEa+uP1LRniCc979en/O"
    "nuL7dLPwUs8r05URLtx4Ivfv20u331+BYI+Wzh0dn2Dztu2MTU3iMwJkolwCI3xm74N8ZM9u9k9t4OLnPYef+qnn8xNPfCKjtdrD"
    "snyPzFOECd6rH8utFl/8ylf51Kf+D1/5l2vYOjfHK7Zv5/LtOzA45ntJaO6QTfXMyZxckKwYRJVWo8GhgwdYWFwEwnDJh1ufXJDL"
    "cYkTtm/nG4d2Md9uEkdhSmgJ4ZBY/jQadz0bWav+K8uHnvokuCrHhXq8BKBgCMsbd55Usu7WFDMx7fu8qTcndXUkBLXWSz3bRiY4"
    "a2or9z64lzRNw9iSYyBuXJoAhtGJMWY2b2V8cgq1FvWekSgijizfmZ/n6r17+WK7RXvjJk6+8CIuuvQSHn/BBZx2yilsnp5e1/ce"
    "nJ3lnvvu45av38YtN32J+7/+Nar7D/Kkep3n7NjO2dPTuNSx1O/jNeuzWOSXuaLHkcXgfEpjaZm5w4dYXloKTSgexUTmE8FLNgpU"
    "7+I+HmwsUM42P6/oeXs0prtNiSosdtGLeocO3T8c7z+eAlAEi6qbt72oJOaqtkpylmvF/76/gMvMgBGhm3pOHt/AqeMbuW/PHhL1"
    "WCPosbRszVwtgPrICNMbZpjYsIGoXEEJTZHrNqLrPd9bmOers7N8c3mZ3QqNsVGqMxuZ2r6NiZkZJqcmmZqcJI5LoRlGv8/CwiIL"
    "8wssHj7M3N69dGYPMbq0zA7gseOjPH7DRk6bCoOZm70e7TRsspW8vsFnajJrKa9Kr9dlaWGB+fl52s1W0BCZnX/EMDqh2VRsI07e"
    "toN7lg/ywNIs5Wgwrq8CvD8a4SZbS8aEOBVe3Dxw4ONrVf1HKwBk2j6tb9r21igyf9DwmjwlacVXJot0hkFL4jl5YoaTxzZw34N7"
    "AwNmzDGNbwkDkxSXqfJSqcToxCST0xuoj41isw0tW0PZRKG+MU2Ya7fY2+rwYK/LwWaLVpLQSlP6WdexklhGIkstitk0OsLWcplt"
    "9Toz9Tp1G5GitJOUXpqGnIMhnEA2qTTvyd/v9Wg1GyzOL7C8tESapEU0cS1l8aHVnCOOIk7dvoPvLR7ivqXDlCNTDOYYEeFjps7V"
    "UT0ZNyZO1L2tdfDgW/O9WdeSHuVWBCHYsv2DkbGvbjqXPDttxC9KlmmrAfGFJjhpfJrTxjaya98+umkSKo2Plc3LELR6nwWUhLha"
    "pj46zvjEBLWREeJyBbExxigRQmQNMaGGX4oW7Ay12gqp64l3JF7pO0fiXVZkrBhM0UbGDJopBvq606HZaNJcXqbVaNJPeisCS+sp"
    "hE2SlHqlwolbtnH30gF2Lc0GtZ9VP48qXB3VuMqOJCORidX5Dy0fOnjl0Wz+sQhA+LstW6ojRJ8zIhe3nUtf4JrR8/vLNIpJ6CGj"
    "ePvoFGdMbmHPwf20Vwc1jkNwJw+juqwXThRHlCtVavUa1foo5VqNuFzGxlHWuMkMmu8WefaDvkPFsEsGTafUZ00lk4R+r0O3E1rk"
    "dNod+r1eaNWaBX+KDuPruMegNRMmRsfYvnET357dw4PNRUpDJ38U5Tpb46N2NK0aiRS9pWHMZezf31mLz388BaDIGxjfuXMyTfVa"
    "I+birk/TFydL0RVJiyYGo6GXYC/1bKyOct7Mdg7NzrHQXCaO4uPO6w+3ZRtG/MYaIhth44hyqYyNS5TK5TBtKw4NI4drn9V7vPOk"
    "rodLHUk/Ien3SPpJ0WFUs6idWTXveL33lGevJy5l8+Q0U5OT3HbwAWY7DSqRCcnLRhlTuMFW+Eg0mlaMjYz3t9ArX7G0tHthLf7+"
    "90MAVgiBS/Vag1zc8T79mWQ5ek7aoM2gO3UvVUZKFc7fuJNeu8P+2VmssYMO18f7MTTVLLfVvqj9G26quiqxTR7aEkmGWsPnzTGP"
    "dsMf4uH4YMJ2bNqMKUXcdmAXTdejbAxOQ7u9OnBtVOZ/2bG0Zm2k6m4x5fIVS7uPbfOPhwAUQsDOnZMjKdca4eK2c+lzXSN6Qb9J"
    "N/MOIoREPUYM523YwaiU2HPoAEnqHtEXPu5ycZQM4aM1xT6qsLELBM+OjZuZ67f51uEHwloZU9ReVIBP2RqftKNpNTIR/vht/lqZ"
    "wLWsjWFpqVOdHP+4d/r0ijE77jClZBFjz/ehRUkKxTjzBxuLRFHEidObcc7R7nTC6LMfEJf/w3zkGT7qPVumZtgyM8N3Fw9y1/y+"
    "MJhSQlZPjBCJ4R+jUa6OasmoNbF6f4vpla9YOnR8Nv94aYAjYoJIzMXN1Cfnayd+dX+RUXXkVccGoec8E6UqZ27YhiSOA7Oz9F16"
    "VDGEH4uNH7L1I5Ua22c20hXHtw/tYanfLcCeQ6ihLIvhQ9Eot5tKMmpN7LzeYrrxMdv874cGWKEJektLnbFS/NHERJsq1ly0VyL3"
    "bVOWEzSVLT6hl401ia2h4xIebM5TKZXZPjWDRWh3u3i0aLP6f8OJh5DjYKxh54ZNzExPsasxxx2H95BoSskGla/AmMJ3bYn3xGP6"
    "PVP2o9ZE3vn3l1zy8wsLB5aO5+YfbwEohKDT6fT6zeVPmpExqQhPW5ZIbjUlVxXM6T7BAwlhDq8Ah1pN5notZsYnmBmbwKUpnV7m"
    "S/+YmoX8qlPnMCJsnJhix6bNLJPwzYO7ONBZppTNY0gRYqCM4Ya4wgeicdc0kakbjFP/tsahg2/sdDr94735x9sErP5cAXx9646X"
    "GPXvBjvVVZde4trRi5ImI5rSyTp8m8wueg8z9TFOGttI7JW5xUWWu+3APBm7bt/6h3XivQ+cRGQt06PjTI1P0PIJ31s4wOF2A2tC"
    "FXU+JaSOMkfMVXGNr9hKWjcmMl7nU8wvtw7u+xiDbF79fgnq9+sRAenotm2nofIBEXlSy4vf7Hu8sL9sLvBdeihpmFyBCCRpEIhN"
    "oxPsHJkkcoaF5WUa7RYumzVsRJDvx2ocAzNJzj2oUopjNoyNMz46SssnPLB4iAOtJXwWs/DZjIMSoXXLl02Ff47qfsGUqBmMKl/S"
    "VF7TmH3wu0fL8P2oCABDNxCNbN35J1Z4Q0/BeZde6lr2eWlLZnxKJ9NtNvPDEx8KNjfUxtk5Mk1VYlqtJovtJr2kn42iMUWs/wep"
    "GfLJBGRBm1CqbRipVpkem6BcKbPc77Jr+TCH22EmQRzms+GyTa+psMdY/k80ql83sSuLjSIDzvOO5sF9b87X7Pu5+T8oAWDYdtW2"
    "bL/CivkzRM5pq2fS9d0VadM+2XWoeE8n6zJms3knSdYyZaJcY8vIJJOlGiSeVqdNo9OmlyZZe5pB+dawftDjskCDDfdD3cKMtdTK"
    "FSbqI2G8nFEOt5fZ15hnoRcaNMZZG/6wm6Fka0ks/2aq3GDrrmWMrYfqqG874U3t/fuvXb1m/zcIQP5dhhCqLI1s3fk7Bv+7Tkyp"
    "57w/0ff1J9OmPd/1iFTpSuC/DaFuIHWKUyhHETPVUWaqo4xEZcQpnW6XVrdLL+mRuDSvrThiwYcgK+YEsIITHB7QMOg2plm75sgY"
    "SnFMvVxlpFalUirjBJb6bQ60FplrN+hp6E4SZeHvPGevitISw5dtmRtM1e03sVSNNUZ9H+S/LU/t+yPupM8giVN/UJvyg34U8er6"
    "pu3nipG3GDEv6wmoS/0ZvqdPT1v2bNeljNJDSLI2p4aQbZNkefRlaxmv1JmujjIaVygZC87TT1J6/R69JCFxKS5NccOlYEdy0BmM"
    "o82jeKUoohzFlEtlKqUSURyDETouYanXYq7dYLHXpuccltBJxYjJengKEUoFWBLD10yZz9uq221KUjLGxCGP4KNe/R+2Dh68Y/Xa"
    "/KC9lR+Gl2QKQdiy43Ij/s0Wc3lHLaqJP9V19Ym+ax7nejKqKSlCP+ublQPG0M0jnJcIqMQl6qUKI+UqI1GZqgljW4rRV1nHr0EV"
    "DsXk8dC4QkJfvXzcOkriHR3Xp9Hv0uh3aPa7dNIktM6R0EQrYBDwoliEkgay66BYbrUV/aop+b0mlpKxJozo1etU9E+W9++/bmjj"
    "f2Cn/kdBAIaxAbmtG9uy43IVfTOYy3tiUJeySRP3ONeVC1zP7PAJMY4+kGAyE0ERUAoofEDZW4HYWGIbUbIRJWMx1hKJKVLRZajz"
    "Ruo9iU/pexcGZbuUJPvM3HIYE1Q62SRSJbRhjVBioCWW70nM123Ff8uUdNFEtmQMpRCEWr3xK+7/h8lX/LAf+ZAcHzTClsst9tcU"
    "rkisLSdeqfrEn+z6/nzXNWdp32zUlFgh1dDMNcnmq8jwCLm81k5XDlN6SMv9VZPOi1nLxQQ0KaKEKmBUiTOgKkBbDA+amDuk5L9l"
    "Sn6fKZnUiKmIYJ3vIXqtCu9ctfHyg1b3P8oCwJFU4ciWE84U/MtE9KUee2Yvq5odUe93uq4/zfflVJ+aLZrIiDribFZgSt7hV7PZ"
    "RVIMmHvUu88bHQ/1NgztVEOHMwR6RCwYw16J9B6J/b0m0oMmNh0TmZJAjGKc3uXQ/6WGjzb377/rSKbvR4mx5EdQEAqNwKmnlkfb"
    "vStEeYHC5d7I9j4GVU9JUya8d5s10e0+ke2amE3eMa4qZTzljE/QoeGPD9PxeJABlI2/S0ToidAWyzyiB8WyR2K/10Z6mEgaxtpU"
    "hJJIpuL9XoHr8PLPi2O1a/ne93o/aif+x0UAeLiFm5qaGnOVysWq8mwVeap6OSe1puqzPgJWPSX1jHivE+r8OI5RVMZ9wqgqFVFT"
    "zlR4jtd9BjB7IjRFfFMMDSyLEumiwJJY0yWSngliYo0QKRifdozKtz16o6hcY9PuLfPz88sPK8g/wjGLH4fYSg6YVpyiya1bd3g1"
    "Fyo8ReFxoGd5zKQaKYfW0LntD66jyQdcQtaGfVDP6ofH5xqDzZIyLIp43xNYMPAdI3JbH/+FWORrC/v27XmYANsPBdX/3yoARxKG"
    "XDOsWOTxE06YSJ3bbtTuxKeXCNSASxRiCZvzGAUrQ6Z+iApwKLcbcGpIBG52+DbG3OzTdHfU7e5dWsqGH668nuGTrj9Oi/n/AZqT"
    "T8IATtzsAAAAAElFTkSuQmCC"
)
ICON_64_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAedklEQVR42s2bebRlV13nP7+99zl3Ht786lVVUkOGSqVSCYEwBGEZ"
    "IlEaEFoCjUsSAQUBAx3W0n96LXuJrG5sGwRtFRIGW3AxhCgKQURkaKOoECAkqSQkqQyVSlW9+b173x3OOXvoP855t15VKilEtPvW"
    "uuvWe+/cc36/728etvDjewmgAbv5i6+Dee3MzL4V5y7OUM+AcDkwpuECTWhKkAAQBPEhdGyQB5Cwiqjvgv9eTetDvzY/f/9vgQ0n"
    "n2MAB4QfF9E/jnuogihuAf0r09PP7nheGQgviUO4oCWhNB08UzgmgqcZPNXgiQlAwCEMRLEhwqpoltDMo1iBpCfqAY/6UtnxFx9f"
    "XfjWa4rnFGD7fy0Q/1oAzKbEd09PzxwP4fokcF2VcMm5eC7yKef5jNlgfT24YAIScqolhPzZoSBChKAgSK4RYShKFpVSj0rMvRLz"
    "IJpV5G5BPnGu7n/80YXefDiNhn9PAFRBe9gzU5t+wlbflglvmRU/8wyXcLlPwjk+czqgMpAgIpGOKEUxFRNT0oZIaZTkj/c+kAVH"
    "4iwDmzK0KanNUCGEGIIo/KIYfZeK5Z+lxCPoeYd8aLfp/9HD872FTQwLjfg3B8AAVoD65OQbe8i75/BzL3RDnueHthGcGgYUWtEs"
    "1ZmsNBiLq1RNhBGFEkFEQATZogEhBAgB6wM2OPouYy3pszTcYD3pEayjqvCZiP+elMzf6goPBX0sUvxGtrT0Mf8jaoP8KMzPTU5e"
    "cAL1+w0JP/0i2+dqP7C14HU/IJW4wvb6GDPVJjUT58wpQUyELsXoOEbHEcoYlNIghSp5h7cOl6b4JMUnCT6zeOfou5SFQZejG2v0"
    "0gFVIQRR7nZVMl/SNRbhy9vgHceWlh74l4Ig/4LrBPDNycnX9JA/OoCdeLXdsDt9prsBqcVl9rSmmam2MErwgC6XiRt1SrU6plxC"
    "aZ1Lf1PigIgQQhj9fvNv3lqyYUKy0cV2N/BJRuYsC8MuD68v0k0HtBRhGe1uMTXzbeLlmudt3dWlW8IWE/1xACCAKPDx1NT7BW78"
    "D67PS93AZd5rpzXnt2Y4pzmBRnBKKDUbVMfGiKtVRClCCATvN7nbcmcpfpZTaS3AEKUQEZy1DLsbDFZW8P0Bznse763w4Oo84h1V"
    "Je4rqqw/p2vYED6QLS+/0/+QIOgfJsQp8Gpq6ua68Ku/nHXcT/qBrPugxioNnjm9i5laCxcCcatJa8d26hMT6Cg6lfGtzG2+Rz+f"
    "4fcFWMF7RIRStUql3UKVSrg0ZUyXmK216diUlSRRl4gNu4L1h3T5yqRS2c5g8Plwdv6e9oKR5GVq6uYZeNPbs7XsgpCatYCc357h"
    "4PROtChCFNHesZ3G9BTKGIJzT5LmmV4+hFw8hUM8MxWFyRRAxtUqlVYLGwKSpmyvtRElHB1syA6cutin2T26dMWgUt/OoP/5whz+"
    "xQAIoBU4mZq6eZbwphuzNTvjbdQTxTMmz2Hv2DSps5RaLcbPPYe4UsHbIi+Rp7csDxitqUYRsTEEEXwIowghZ/r+ViBEqLSa6FKJ"
    "ZGODqVKNelzmSL/LGE4f9Jm9S8dX9CvV7ZJrgnkqU3gqAIyAjaem3t8W+dX/nK5mU8FGA9FcMb2LbY0xEptRm5ygvWN7nsU4d1bG"
    "RYQgQsMYVlZXObSwwNHVVUppSrNcZpBlUGRIm/b/JEC2ABFXq5QaDQbdLk0d0y5XOdLr0A5O7fNZ9j1TucJXKm03GHypiA7+hwFA"
    "A64yNXWtUfK7N6Rr2TkhMz1R8uzpXUzX2gxdRn1ygubctpM2/jTMK6Xw3jNMU0yW8cXDD/OV889Hv+rn6Fz+TL66ssrSoXvYW67Q"
    "HQ7IhglpkmKtgxBQSqO0epJGBO/RUUSl2aTf7VITw1ipwqO9daZwantw9tu69PxquXwoGQzuKXgLTweAAvzU1NTeDVFf+HnbLT3L"
    "p3od5PLJc5htjJG4jGp7jNb2uSc7uDNJPAQGgwEb/QFlUXzj6FEef93r+PX3vIdLL72USy69lBe84hV8dTCk88//yPlj4yTOAx5n"
    "LWmSkgyHuMyilEJvCaWIgPcoYyg3G/Q66zRURD0q8Uh/XXbhlYJwp4qv2VGv3drp95e3ZLEjhk+hOYBaVPqmK30y9iI3DCs+yL72"
    "LHPNcVLviCpVmttmR3H86ZhP05TuRo/UOnQckyQJh/bs5R3vfCfa5ww6a9He8/Z33sjdu3YzHCaoUoyYGIkitDGIEpI0ZX11ne7a"
    "OlmWoZQ6qQnOoaOI8XPOIVUwVx9jX3uWVR/kJX4YLiMbeyKEmwqHKKdL/BTVj6dmr9sW3NWvzrp2wwc9W22ytz1DFgIoRX1qCm00"
    "PIX0N6UzGAzpD1PQGjERcRSxMOgxecmB3BhDQBuDNgYfAgaYuuQgC4M+cRSBViitQRtEa3Rk0JEmSzM6K2tsrK+PzGsThKhSob1t"
    "jsRZ9rZnmKk2GXqvX2N7tg1X18bHryuqVn06AAKEfXONCS/89suzDd8MTiltuHhiO0GEIBCVy5RqVbzzZ7R5EcE5R68/JHEOZXSe"
    "RShBtCEohWh9RnccyONOfo0BlX9XtAJlQBlEFCoyKK0Z9oesLy2TpelJEKylPNamMj6GD54DEzsI2jAbrHqx6/uhqN/e12hMbClB"
    "RgAoAX9/Vn/7RWSzz/VDvx5QF7RnqMVlnBReWWtE6zMyLpKraac/JCMQtMarXIrKGJRRiNEnn/wUKakYjSreonUORAEMxiBKobRC"
    "RxHOBzrLyySDwcgkgvc0pqcJUUQlirmgPUsnoK4KQ38ufvbBuPz2IhqoTQAE8LtnZqYj/A0vznrB+6DbpSo7GhNkwaOUQpTC2ZRB"
    "p4MoyQkpHmqzjO5Gj0FmaZVLNLSmZQytSgWMzuEtADxr3q0VaCk+FcFo4lKJarlEFMd4rXMwFCitCUrTXV1l2O/n2uU9Jo6pT06Q"
    "esvO5gTNUo3Ye/0iPwgQbtgzU5suQBBTxPzsYdHX75d04oBPbB/MvtY0WmmsFImNEkRpeqvrpEmCiUsgCh8cmfeUShVCmvDF+QUW"
    "mg1U8OxOUp6/YzupMYgxuWo/Xa4ggugI0RFBOYzWlL3j0cVl1tOUttbsHBujrzQ2TRHtUGh8CGysriJKUSqX8c5RabXpr6wgmWNv"
    "a4o7F3pyhU/sV3V14ogtXw+99wKRAty1EIsPb7jSDYLyQTXLVaarTSweUQo2pS0KMQprLcPBkCQdkjlPpVylu9HlQ95Tf9dvcu2n"
    "P83LPvGnrL75zXxscQnjQ2HX6uzVlxKCUsRxmUGSctP8Il997vN45Bd+ga885zl87MQC2XBAqVQmiBTamPuLjZUVbJbltzGaSnuM"
    "zFmma00apQql4NVz/CA45A2vhhhwBvCfm5m5bDq4/Qfc0A8Etbfc3MxgthQrqgBDQJk8MdGKKC4x6G3wUaV440c+wr4dO0a8nHfd"
    "ddy2YwdfePe7uX7/RQSlz6IBINqgI0OW9vjj/oCX/eEf8uyLLhpd8s277uKmX/813tzfoFypkiYDRAkQEbKU7vIKrekpCCHPDZaW"
    "0MDO+gT3Lx9Vl/nUf9lU9982Pn4ZKyvfUgJY0T93YbC0nfPGxNSIcIT8xiIn01IliOgC9dyzG2f52GDI9TfdxL4dO7DW5lVgCDhr"
    "eelVV7G4ezedXh8dx08v/SAEpWmUytx+Yp7Lb/hVnn3RRdg0xTmHs5YrDx7kdTfdxMeGQ7S1iIkKOkF0bhr99S6IYOKYqFrFOs90"
    "rYnWhhlv/XlYBsr8nADqWvbHyvuX7fdDPKhmVMmzK60QCgBEgRQhTRSiBC9CK4q45fgJXvjf/xsHdu/GWosxZhQVVKHy5YkJBt5h"
    "jDlr8S0m/85CXOLgZZfhi3RXa402BmstB3bt5iff8x4+c+I4bRPhC+FQhMlBt4NNEkRr4moVT6BiYsbKDUJAXewzVAgvuxZi9Zez"
    "K+c18eftchmZQjVUTOYcSuncTaqiGFEna/cgQq1U5s5jx8le9Spe/IIX4Armt3Z1RIRultF/5BHGmy0sclYnGLRGRRE6eAbD4cl+"
    "4WaVZgzOWn7q+c/HXnst3z1+jFqpXKCXgwDQX8sTpahcys1WhKlKnQzUeT6lhj/vS7Pj56lUzDOm8aUxb73SEXEQvPcjxmVLwyJs"
    "aoNShCTl75oNrnv72wne51nbVm0uytYPvve9PMdaTLWWE3I2H6gMqTYcrJT5m8/emneU/KmpkyrC3XU33MDftVqEJM1DZ8GoMpp0"
    "MCQdDDClUl6MEWiXqqAUk8H6SfGlvjfPUAQOzOKIQwglHSM+4IIfqX/OeOEDUASBRhRzx+Ii57z2tUw1GvjTenreOZTW/N5738fu"
    "r3+NK/fspWdtnkI/bf0A2igGznLpObsY+/rX+MhHPoo2GrelySJF/2Cq0eCc176WOxYXqcelotY9qQXDTidPwnSebleimJKJKYUQ"
    "tgWP9xxQhPDMae8gIGUTEazPOzVbS/AtYKAEsoy76zWufuUrCSGcLEwAX2jDrZ/7HI0v3sarLr2MtSzFGJWHq6ftGeQhzWhF1zle"
    "d/EBsj/9OH9x221orfFb6g9V9Bpf/MpXcnejDqkdaUCuJYq0P8BbizaGEAJGNNWoBAGZCQ4Iz1QQxseDwwuUlMF5j/eeENjSkDjZ"
    "GI5NxBNr65Se82x2TkyMenZb7f6xEye4/8M38/MHLmYhSYk2U1mlnzYPCDnloDRaC8s24xcPHOCuD32QJ5aWRuX1qNT2nh3j48RX"
    "XMHRtVXikQ/KM0/vPOlwgIpMkWIIVZMP5CZxKBhXEeH8enB4kEg0Pvg85HhXxNe8EMrfgbJSHE6G7Hn+T+RNy9PsXkT4q09+kheX"
    "StiolCfcokbhM5y1CZmbHKKQEPClMj+lDV/81KdGTJ8CWAjs/Ymf4OEkoayKQktO3jAbDEcmgUBJG1xAGsFjCOerSGiWQwBBNDmB"
    "zjmyzOYP3FKqBEC840Qcs+fi/bnD2SJ9pTXLvR6db36Ti2Zm6KcpSp00HxHJ/eCZegmF9siWyZFSil6acfHsDCu3387acHiKs1XF"
    "dXsuPsDxOEb8Zlsup1tEsEk6csgAkTIgSDl4DDSVBIIZsSkjO07SpFDtkwMsEcGmlkG7zczstlN7dAVT9x46xLZul7hSZqQfIljv"
    "mWg0WD1yZPQd59xJ5ybC6mOPMdFoYp0bRZ8QAqVKhZn1Dvfde++Ivq3Pnt02y3BsjCzL2By5yqazdBbvbJ5iA1qp/DOvBIPabANt"
    "1ZxAoN8fnDbIyCWU2gxXb9CoVk9pgGwCcPzwYbZHETacBHST2Xarxe7FJT7+mU+jtM6TG61RWvPxT3+aPUvLtFstrPOnRAYHbNea"
    "Y4cPP2mqBFCvVHC1GmlmRxp5ypTJOUaTyHDqqMsEQbLNv420VdHv93OklRlBIyK5dMol4s2pzuYDixv3Ox12FmFnZIrF/zvDIT+7"
    "bx+f+rM/530PHubgC56PINx5++2M33UXL9+/n85wiFYQNlciAvgAtUhzougCnW46sQhSLuO8A4lHJhAotMiFkRb74Eet+QBiLNJJ"
    "RTWB4PJUByXCMBkyHA6p1Rt4ThKzqZbhKYu5AphQ6FIISPGpgIG1XHfJQR44/gT33XwzIPxMq8WFl1xCd5jk1/pwkvMQivtw5nnB"
    "Fmd46iCsgCCc6nIy7xAIiYhY6JhM5MENpZ+pAsEGLyWtCTYjeM/6+jr1RhN8QHR+o0gpGA5IQ8Cc0q/PP6rtMbpZmrdeg0e8Kojz"
    "BK8Az/qgz67pWfZt344AQ+tYHwzRwecOK/g8woRcVhIU3TSlPjZ2xuwpDQGGQ4xWZCHkviecopi5uENg6CwqEPqiJUUeVCHIygp5"
    "fB66jEibUXKzvr5WOJY8/nrvibVBdzp0ehtntMft55/HUevQfpOZgHch1y/n8kIrBIbDAavdDVa6GwwGw+L6fBYYvCM4TygA0d7z"
    "hPNsP//8M/qdzkYP1ekSmyhP40fc++KaQouAgU3RAqui8bCiQH1nXhuAMHTZKF1VSjEcJqyvraJEgc8J0pGhtrbO8aPHTiFCqVzS"
    "F+/fz/xYm0GvXxCRMx1cAG8JzhGsQ3xAFW9xm0xbcA58wPuA5OpKf2ODxYlx9l94YTEoUac8+8QTT1BbW0UbPVq0oKgfJBQhFqE3"
    "HNLLEgTCQl7dfUch3HMcQ6aQYZYgJt/i2IyjS0tLeGdzrxk8XhRzWcrhu+8u1PSkgTnvaZZKTF11FXcfP05NR3mYCzaXqAvgHXhH"
    "sJbgirfPP/EO7zzeecTnIbJmIr5/4gSzV19NPY5xWxOhgtmH7r6LbVmKL5Knk35j0wdBlllWeh0yn5EJclw0KO5RceB7C6hkVUXK"
    "uYyEXM2D92it6ff7rCwt5/2BEBhaz55SmUdu/7tRcnN6fv6y176Wr2lF6PcJQfKhaSF9bz3ebWHe2RwM6/HWF0BYgneAYDc2+EYU"
    "89LX/Kcn1R2bCdMjf387e8sVhs6jKEyvcKAh5I2d9U6Hvk0J3rEuWs2jklip76lXjNcf6ij90KM6xnh8xyaUSyX8FtWenz9OOkxQ"
    "AkmWMttqEe64g8PHj+fJRiGVzVx9dmyMZ994I3/yg/uZMhrn8/Q6eAvOEqwrTMEXbzcCQ3z+s3WBSa35kwce4Mp33sh0q3nKJokv"
    "0u7Dx48Tvn0Hs60mSTFcpXCeIQS0UvR7A7r9HgNxaBf84ypiVdRDrxg/8ZC69d57Uy/6tkOmghb8WtojLsWjRoRSijRNOX70KApB"
    "gsdpw+WDAX/72VtOKVBGg1DneOmLX0z1jW/kY3feyaRSRChsZvG2AGFT9Qtpb/qANLNoUUyI8JE776T1pjfxMy96UV5ib5H+Jhhf"
    "ueWzXD4YYJVBhULyPuQCLP5/bOEE2mjWswFG8Id0CSdy2633kqoAGKX//H4Vs6q1GqZDEhUom3hkQ8YYlpeXWF5YIDKabjLk0slJ"
    "Fm/5LEeWltCng6A13jl+6Zd+ieoNN/C+ew/RXVliPIqIlMa7gLUOl1lcZrHW4p0nFs1EZOguL/G+++6l9Y538PrXv37UX9jKvBbh"
    "yNISi7fewsGpKXppmhdP3hMKMzBKM7+0QDJM8JFimA7pKqXuEwMifz5KiV+1Y27hjmHyqjn81F6bhlREJuIavWQ4Si2VUnTW12k0"
    "mpTKZYKJGO90+Pyx47zgmmueJCEpRuKXHjxIfPmzuPX73+fIAw9QSxJaWlPXmooIZRFi73HDIY8vLvLXTzzB32+f46ff9Vu55M/Q"
    "bdoE5A9+811c/eCDNOt1bJYi3oPLfYxWirW1NR4/doxWvcGi7xOy1H/flOX/qPJ9Fy1MvmuRxaDhmea+xbsyqY9V+0pf8zzbcz2X"
    "qalaE5dk+M3CglzKnfU1xsbGcEqxo9nkyHe+wyM7z+HARfuw1j7JSXnn2LltGy/82Z+lu+9C/qk/4I7FRe5ZWua+1WXuXlvnjsGA"
    "b5VKPHHwIAfe8lauf+tb2TEz8yTJA6PG6623fQH9oQ/ygrntdJIiiXIeHxxahI3uBo8dfRwjirha5on+KhG4W6OGPo75naX+I7cX"
    "Q6E8h9szMzN1REX3viVdGb8s6VOvt2ROaix1VtFKn6wFrKVSrXD+RftR5Sq14PngygrX/O8/5nmXHBwReIrEvB+VrgB971lYWmKj"
    "0wGg0WwyNTlJdRO8kNvwVjC3Mv9Pd93Fl9/wet46MUnXe5RzRYSxaCVsdLo89tijpNYyVm8yLwM2+p3woCnxe6a50lZq//z8/OLW"
    "BQm91utthEar2lHmJ6+0A9fJEjVRbyKZz/PngnitNWmS0llfp9VqIZUKz1CKT/7lX9J47nPZOTuLs/aU1ZbNcOWL7DDWmnatxvT4"
    "ONPj47RrNaJCW8KW9ZjTKzpjDN86dIjP/8qv8KZajVQbGDlVj9GK9bU1HjtyBOccpShGVSMe761QVuI+FTX1Ucz/7C/Mf3Fz2Xqr"
    "fqm5Zv2uI5jrx/H1C1wSVr2V7fUxev3+KQRprcnSlLXlZcqVCtX2OJc5y2f+7FZ6e/ay77y9o1H56SYhW7K4sCWRki0DmK2vzXso"
    "pbjta1/jG+94B79cLkOpjM0SxHnw+UbX4sICR48eHUWwVqPJo8kqkbX+O6Ysf2Wq87NGv77b7SajifxWALrdbs80W0uPm/g/XmEH"
    "zttUqThiTFfoJUP0lj0dpfIZ4drSEiF4mpNTPC+K+catt/LP/R4XPvNZVKNoxMTpy05buz9yphre+xHjq2nKTe9/P8u/8z/4xfY4"
    "Poqw6RAJAY1gbcrRI0eYn59H6zzvaFVrrOmMlX4Xq5X7aNTWHaVu6Bw//o+bq0Bn2hTVAYJs2/E3z3fDq988XHLriL6ovQ2/MaSX"
    "DDFFR2XrpqdzltbYOHO797Ct1eYfHj/CP+w8h2e97a1c85KXUBv1DDbD1OkNmK1bmWrkK3oh8Dd//SW+88EP8bxHH+N5c3OsZhm4"
    "DCOKYB1rq8scO3aMJEnyoYl3VKISul7mvvUTjBHcn8Rt/be6/NUwf+KaYsrhnmpVVgF+586de49Z+fZ16UrrqmxDNpSRA61Zuqsd"
    "Mm/z4uj0zRBrUVozPruNvbt2YTPLN1aXObxnL7tf/nKeddVVnLdrF6WzDEZS4KFHH+OOb3ydhz//BXY/+CAvbLeo1up004RIIDjP"
    "xvo68ydO0O2u55sjSuG8J1aaWrvBoe48dWfDN00lfNS01seCu2JxcfHwVuk/1a5wviY3u/1ardRnbxwsZLtdYqwpyf76FOur62TB"
    "58nPGTbCnLWYuMTk7Cy7tm0j9YFD3Q4PlEr0d+2ifuGFTO7ZQ3NyklqziQC9bpf1pUWWDx+me//9lB9+hPOGQy5ptmg2GmwUabRP"
    "Mzrra6wsLtHprAMBnVeyOO8wommNtblvYx6TpeGoju37SmNR5uXVg8UTt27y9sMsSxsBa2Z3vH9MceOv9eezMZdFxGX21SborHVJ"
    "nUUrzem9oc3awBUxvDk2zrapKZrVKmmAlTRhxQc6zpEW34lCoKEV40oxXa3SqNYISrGRJgyHA9Jej876Op31dYaDQW4qWo9WbK1z"
    "lLSh2W7xg94iPh3S1SZ7b2kiWvDyAb944p3hKdbo5Syrslbmdt48F/yb3jmYtw1nTYhKXFCbZNjt0c+SUY7wVDuC3jmcD+jIUK3W"
    "aNTr1KtVyqUyJopyxyoKHwKJswzThOFgQDockAwGJMMhWZIVbfdc1cOWZq31jnqpQqVR4/7uApIl9JSyHyhPmsdQH5b5E2/2T3PQ"
    "Sn6YZekwd+7NO0L2prcPFrMJl0WJNuxtTGIGjs6ghyhBceahx9bujd+cOm1ps5+SK2yGxVFoVKN9JDmt+5RPrwJj9Sa2JPygu0jZ"
    "WlaUyf5XeTx6HPNhmT/25rOtzZ91aymAVt31z3ea7e3fj2pX7HWJm/WZPJH0pFQuM16uYTNL5t2TWtJnAkNvbYcXR2i2LklvtsmV"
    "1k/KBDcnFM45SiZiot1mRRIe6izQDD4c1iX/B5UJc1zkwzJ//M3+5Gps+FHPC2yCoFS38/mk0W7fEdWvbAQn+3zqltOB2hDPeK1O"
    "RRsya/PewNOtv/+Ir0DA+YBRivFGE1Urcbi/wkq/Q1Nw34hq6mOlttoIfCDMn7jhx3Vg4hQQQnf9r1Wjed93dfVFSyauXeQTG2ep"
    "nMh6EiJNu1qnrAzeepx3Zz8LcJZjLIG8N0gIlHREq96gVK9w3PZ4rLtIbG3oae0+EY+ZL5rasgnyhmT++O/+uI/MPOnQ1OTc3AVL"
    "RL8/i/3plydrPNf2rHfo1CgZKzWYMGUiBzbNSGyGc4XdF1Pmk9PmLfButvU3O1EIkdGU4xJxKSZVsJBusDroEjsfgsJ9M6qbL0Z1"
    "FtBfnrPhHceWjv2bHZp6EggKYO7cN0J4936fzl2TdrjY9q14VKJRpahCO6pQUzFxyKczzuZTZ+/zHYStkyWlBC0KY0y+Z2QUqQS6"
    "NmEt7TNMB5Q83mrxd+mK+UpU50Exx3TgN9z8sX+3Y3NnODg5M/2wKr8tEv+WC306c2XWZ7/th7Z3zoKyCjE6kpIpUdYRJdFEolHI"
    "aGMmP00ayIInDY6BSxlmCc5mQXuCEvyyNvpuU5F/MhUeJpp3oj6026d/9PD8/L/7wckzHqKcmp6eWTDV6wV/3Uywl+z3KRfbATtd"
    "SttnPioatEHyo7PFv5NWGoqjs/nPIVXIqorVozrmHlPmBxKzjNwtSj5xrk0//ujCwv/To7NnPDwtwGdAv2bu3GcjvFL78JJWsBfM"
    "4EpzwTLtLWPeUQ+WUgiYfC+BDGEowoYyrIhmXgzHRbOATrqiHnDwJaPMX3zy2GP/3x2efsrj8wL8VzDv2rFnH+IvxoVnQLhc8GOx"
    "DxdEQlOKPDoIkgU6mZIHPKyC+i6E70UuHPov80f/TY/P/1/Jjku6O0DCPgAAAABJRU5ErkJggg=="
)


if __name__ == "__main__":
    sys.exit(main())
