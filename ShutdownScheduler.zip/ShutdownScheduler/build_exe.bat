@echo off
setlocal
cd /d "%~dp0"
echo === Shutdown Scheduler: build ShutdownScheduler.exe ===
where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python 3.10 or newer from python.org
  echo and tick "Add python.exe to PATH" in the installer, then run this file again.
  pause
  exit /b 1
)
python -m pip install --upgrade pyinstaller
if errorlevel 1 (
  echo Could not install PyInstaller. Check your internet connection.
  pause
  exit /b 1
)
set ICON=
if exist "app_icon.ico" set ICON=--icon "app_icon.ico"
python -m PyInstaller --noconsole --onefile --clean %ICON% --name ShutdownScheduler shutdown_scheduler.py
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Done: %~dp0dist\ShutdownScheduler.exe
explorer "%~dp0dist"
pause
